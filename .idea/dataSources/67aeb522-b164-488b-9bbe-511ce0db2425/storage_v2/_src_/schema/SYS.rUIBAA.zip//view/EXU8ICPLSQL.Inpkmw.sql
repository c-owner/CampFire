create view EXU8ICPLSQL (VALUE) as
SELECT  value$
        FROM    sys.props$
        WHERE   name = 'ICACHE_IMP_PLSQL'
/

