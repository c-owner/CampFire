create view USER_SCHEDULER_RUNNING_JOBS
            (JOB_NAME, JOB_SUBNAME, JOB_STYLE, DETACHED, SESSION_ID, SLAVE_PROCESS_ID, SLAVE_OS_PROCESS_ID,
             RUNNING_INSTANCE, RESOURCE_CONSUMER_GROUP, ELAPSED_TIME, CPU_USED, DESTINATION_OWNER, DESTINATION,
             CREDENTIAL_OWNER, CREDENTIAL_NAME, LOG_ID)
as
SELECT jo.name, jo.subname, 'REGULAR',
       (CASE WHEN p.obj# IS NULL OR BITAND(p.flags,256) = 0
                    OR rj.job_id IS NOT NULL THEN 'FALSE'
             ELSE 'TRUE'
       END),
      rj.session_id, vp.pid,
      rj.os_process_id,
      rj.inst_id, vse.resource_consumer_group,
      CAST (systimestamp-j.last_start_date AS INTERVAL DAY(3) TO SECOND(2)),
      rj.session_stat_cpu,
      decode(bitand(j.flags, 2473901162496), 0, NULL, 2473901162496, NULL,
       substr(j.destination, 1, instr(j.destination, '"')-1)),
      decode(bitand(j.flags, 2473901162496), 0, j.destination,
        2473901162496, 'LOCAL',
        substr(j.destination, instr(j.destination, '"')+1,
           length(j.destination) - instr(j.destination, '"'))),
      j.credential_owner, j.credential_name,
      bitand(j.running_slave,18446744069414584320)/4294967295
  FROM
      scheduler$_job j JOIN obj$ jo ON
        (j.obj# = jo.obj# AND jo.owner# = USERENV('SCHEMAID'))
      LEFT OUTER JOIN gv$scheduler_running_jobs rj ON (rj.job_id = j.obj#)
      LEFT OUTER JOIN gv$session vse ON
        (rj.session_id = vse.sid AND rj.session_serial_num = vse.serial#
         AND vse.inst_id = rj.inst_id)
      LEFT OUTER JOIN gv$process vp ON
        (rj.paddr = vp.addr AND rj.inst_id = vp.inst_id)
      LEFT OUTER JOIN scheduler$_program p ON (j.program_oid = p.obj#)
  WHERE BITAND(j.job_status,2) = 2 OR
        (BITAND(j.flags, 274877906944) <> 0 AND j.job_dest_id <> 0)
UNION ALL
  SELECT ljo.name, NULL, 'LIGHTWEIGHT',
       (CASE WHEN BITAND(lp.flags,256) = 0
            OR lrj.job_id is NOT NULL THEN 'FALSE'
             ELSE 'TRUE'
       END),
      lrj.session_id, lvp.pid,
      lrj.os_process_id,
      lrj.inst_id, lvse.resource_consumer_group,
      CAST (systimestamp-lj.last_start_date AS INTERVAL DAY(3) TO SECOND(2)),
      lrj.session_stat_cpu,
      decode(bitand(lj.flags, 2473901162496), 0, NULL, 2473901162496, NULL,
       substr(lj.destination, 1, instr(lj.destination, '"')-1)),
      decode(bitand(lj.flags, 2473901162496), 0, lj.destination,
        2473901162496, 'LOCAL',
        substr(lj.destination, instr(lj.destination, '"')+1,
           length(lj.destination) - instr(lj.destination, '"'))),
      lj.credential_owner, lj.credential_name,
      bitand(lj.running_slave,18446744069414584320)/4294967295
  FROM
      scheduler$_lightweight_job lj JOIN scheduler$_lwjob_obj ljo ON
        (lj.obj# = ljo.obj# AND ljo.userid = USERENV('SCHEMAID'))
      LEFT OUTER JOIN scheduler$_program lp ON (lj.program_oid = lp.obj#)
      LEFT OUTER JOIN gv$scheduler_running_jobs lrj ON (lrj.job_id = lj.obj#)
      LEFT OUTER JOIN gv$session lvse ON
        (lrj.session_id = lvse.sid AND lrj.session_serial_num = lvse.serial#
         AND lvse.inst_id = lrj.inst_id)
      LEFT OUTER JOIN gv$process lvp ON
        (lrj.paddr = lvp.addr AND lrj.inst_id = lvp.inst_id)
  WHERE BITAND(lj.job_status,2) = 2
/

comment on column USER_SCHEDULER_RUNNING_JOBS.JOB_NAME is 'Name of the running scheduler job'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.JOB_SUBNAME is 'Subname of the running scheduler job (for a job running a chain step)'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.JOB_STYLE is 'Job style - regular, lightweight or volatile'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.SLAVE_PROCESS_ID is 'Process number of the slave process running the scheduler job'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.SLAVE_OS_PROCESS_ID is 'Operating system process number of the slave process running the scheduler job'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.RUNNING_INSTANCE is 'Database instance number of the slave process running the scheduler job'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.RESOURCE_CONSUMER_GROUP is 'Resource consumer group of the session in which the scheduler job is running'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.ELAPSED_TIME is 'Time elapsed since the scheduler job started'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.CPU_USED is 'CPU time used by the running scheduler job, if available'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.DESTINATION_OWNER is 'Owner of destination object (if used) else NULL'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.DESTINATION is 'Destination that this job is running on'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.CREDENTIAL_OWNER is 'Owner of login credential used for this running job, if any'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.CREDENTIAL_NAME is 'Name of login credential used for this running job, if any'
/

comment on column USER_SCHEDULER_RUNNING_JOBS.LOG_ID is 'Log id that will be used for this job run'
/

