create view PROXY_USERS_AND_ROLES (PROXY, CLIENT, FLAGS, ROLE) as
select u.proxy,
       u.client,
       u.flags,
       r.role
from sys.proxy_users u, sys.proxy_roles r
where u.proxy  = r.proxy
  and u.client = r.client
/

comment on table PROXY_USERS_AND_ROLES is 'List of all proxies, clients and roles.'
/

comment on column PROXY_USERS_AND_ROLES.PROXY is 'Name of the proxy user'
/

comment on column PROXY_USERS_AND_ROLES.CLIENT is 'Name of the client user'
/

comment on column PROXY_USERS_AND_ROLES.FLAGS is 'Flags corresponding to the proxy/client combination'
/

comment on column PROXY_USERS_AND_ROLES.ROLE is 'Name of the role that a proxy can execute while acting on behalf of the
client'
/

