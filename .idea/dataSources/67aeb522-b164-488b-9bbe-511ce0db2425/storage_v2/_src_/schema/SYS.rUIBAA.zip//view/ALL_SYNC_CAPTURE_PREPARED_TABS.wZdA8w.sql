create view ALL_SYNC_CAPTURE_PREPARED_TABS (TABLE_OWNER, TABLE_NAME, SCN, TIMESTAMP) as
select pt.table_owner, pt.table_name, pt.scn, pt.timestamp
  from all_tables at, dba_sync_capture_prepared_tabs pt
  where pt.table_name = at.table_name
    and pt.table_owner = at.owner
/

comment on table ALL_SYNC_CAPTURE_PREPARED_TABS is 'All tables prepared for synchronous capture instantiation'
/

comment on column ALL_SYNC_CAPTURE_PREPARED_TABS.TABLE_OWNER is 'Owner of the table prepared for synchronous capture instantiation'
/

comment on column ALL_SYNC_CAPTURE_PREPARED_TABS.TABLE_NAME is 'Name of the table prepared for synchronous capture instantiation'
/

comment on column ALL_SYNC_CAPTURE_PREPARED_TABS.SCN is 'SCN from which changes can be captured'
/

comment on column ALL_SYNC_CAPTURE_PREPARED_TABS.TIMESTAMP is 'Time at which the table was ready to be instantiated'
/

