create view GV_$ALERT_TYPES
            (INST_ID, REASON_ID, OBJECT_TYPE, TYPE, GROUP_NAME, SCOPE, INTERNAL_METRIC_CATEGORY,
             INTERNAL_METRIC_NAME) as
SELECT "INST_ID","REASON_ID","OBJECT_TYPE","TYPE","GROUP_NAME","SCOPE","INTERNAL_METRIC_CATEGORY","INTERNAL_METRIC_NAME" FROM gv$alert_types
/

comment on table GV_$ALERT_TYPES is 'Description of server alert types'
/

comment on column GV_$ALERT_TYPES.REASON_ID is 'Alert reason id'
/

comment on column GV_$ALERT_TYPES.OBJECT_TYPE is 'Object type'
/

comment on column GV_$ALERT_TYPES.TYPE is 'Alert type (stateful vs. stateless)'
/

comment on column GV_$ALERT_TYPES.GROUP_NAME is 'Group name (space, performance etc.)'
/

comment on column GV_$ALERT_TYPES.SCOPE is 'Scope (database vs. instance)'
/

comment on column GV_$ALERT_TYPES.INTERNAL_METRIC_CATEGORY is 'Internal metric category'
/

comment on column GV_$ALERT_TYPES.INTERNAL_METRIC_NAME is 'Internal metric name'
/

