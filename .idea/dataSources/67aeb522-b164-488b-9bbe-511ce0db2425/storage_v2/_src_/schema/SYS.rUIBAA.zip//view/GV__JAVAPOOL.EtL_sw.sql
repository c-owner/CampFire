create view GV_$JAVAPOOL (INST_ID, CATEGORY, MEMUSED) as
select "INST_ID","CATEGORY","MEMUSED" from gv$javapool
/

