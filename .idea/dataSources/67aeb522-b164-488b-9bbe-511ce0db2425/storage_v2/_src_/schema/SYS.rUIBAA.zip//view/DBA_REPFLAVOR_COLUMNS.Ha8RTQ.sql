create view DBA_REPFLAVOR_COLUMNS
            (FNAME, GNAME, SNAME, ONAME, CNAME, TYPE, POS, GROUP_OWNER, TYPE_TOID, TYPE_OWNER, TYPE_HASHCODE, TYPE_MOD,
             TOP) as
SELECT fname, gname, sname, oname, cname, type, pos, group_owner,
   type_toid, type_owner, type_hashcode, type_mod, top
  FROM repcat_repflavor_columns
/

comment on table DBA_REPFLAVOR_COLUMNS is 'Replicated columns in flavors'
/

comment on column DBA_REPFLAVOR_COLUMNS.FNAME is 'Flavor name'
/

comment on column DBA_REPFLAVOR_COLUMNS.GNAME is 'Object group name'
/

comment on column DBA_REPFLAVOR_COLUMNS.SNAME is 'Schema containing the object'
/

comment on column DBA_REPFLAVOR_COLUMNS.ONAME is 'Object name'
/

comment on column DBA_REPFLAVOR_COLUMNS.CNAME is 'Column name'
/

comment on column DBA_REPFLAVOR_COLUMNS.TYPE is 'Column type'
/

comment on column DBA_REPFLAVOR_COLUMNS.POS is 'Ordering of column used as IN parameter in the replication procedures'
/

comment on column DBA_REPFLAVOR_COLUMNS.GROUP_OWNER is 'Object group owner'
/

comment on column DBA_REPFLAVOR_COLUMNS.TYPE_TOID is 'Type OID of a column of TYPE'
/

comment on column DBA_REPFLAVOR_COLUMNS.TYPE_OWNER is 'Type owner of a column of TYPE'
/

comment on column DBA_REPFLAVOR_COLUMNS.TYPE_HASHCODE is 'Type hashcode of a column of TYPE'
/

comment on column DBA_REPFLAVOR_COLUMNS.TYPE_MOD is 'Datatype modifier of a column'
/

comment on column DBA_REPFLAVOR_COLUMNS.TOP is 'Top column of this attribute column'
/

