create view DBA_LOGSTDBY_UNSUPPORTED_TABLE (OWNER, TABLE_NAME) as
select owner, name table_name
  from table(sys.logstdby$tabf)
  where gensby = 0
/

comment on table DBA_LOGSTDBY_UNSUPPORTED_TABLE is 'List of all the data tables that are not supported by Logical Standby'
/

comment on column DBA_LOGSTDBY_UNSUPPORTED_TABLE.OWNER is 'Schema name of unsupported table'
/

comment on column DBA_LOGSTDBY_UNSUPPORTED_TABLE.TABLE_NAME is 'Table name of unsupported table'
/

