create view ALL_REFRESH
            (ROWNER, RNAME, REFGROUP, IMPLICIT_DESTROY, PUSH_DEFERRED_RPC, REFRESH_AFTER_ERRORS, ROLLBACK_SEG, JOB,
             NEXT_DATE, INTERVAL, BROKEN, PURGE_OPTION, PARALLELISM, HEAP_SIZE)
as
select "ROWNER","RNAME","REFGROUP","IMPLICIT_DESTROY","PUSH_DEFERRED_RPC","REFRESH_AFTER_ERRORS","ROLLBACK_SEG","JOB","NEXT_DATE","INTERVAL","BROKEN","PURGE_OPTION","PARALLELISM","HEAP_SIZE" from dba_refresh where
  ( rowner = (select name from sys.user$ where user# = userenv('SCHEMAID')))
  or userenv('SCHEMAID') = 0 or exists
  (select kzsrorol
     from x$kzsro x, sys.system_privilege_map m, sys.sysauth$ s
     where x.kzsrorol = s.grantee# and
           s.privilege# = m.privilege and
           m.name = 'ALTER ANY MATERIALIZED VIEW')
/

comment on table ALL_REFRESH is 'All the refresh groups that the user can touch'
/

comment on column ALL_REFRESH.ROWNER is 'Name of the owner of the refresh group'
/

comment on column ALL_REFRESH.RNAME is 'Name of the refresh group'
/

comment on column ALL_REFRESH.REFGROUP is 'Internal identifier of refresh group'
/

comment on column ALL_REFRESH.IMPLICIT_DESTROY is 'Y or N, if Y then destroy the refresh group when its last item is subtracted'
/

comment on column ALL_REFRESH.PUSH_DEFERRED_RPC is 'Y or N, if Y then push changes from snapshot to master before refresh'
/

comment on column ALL_REFRESH.REFRESH_AFTER_ERRORS is 'If Y, proceed with refresh despite error when pushing deferred RPCs'
/

comment on column ALL_REFRESH.ROLLBACK_SEG is 'Name of the rollback segment to use while refreshing'
/

comment on column ALL_REFRESH.JOB is 'Identifier of job used to automatically refresh the group'
/

comment on column ALL_REFRESH.NEXT_DATE is 'Date that this job will next be automatically refreshed, if not broken'
/

comment on column ALL_REFRESH.INTERVAL is 'A date function used to compute the next NEXT_DATE'
/

comment on column ALL_REFRESH.BROKEN is 'Y or N, Y is the job is broken and will never be run'
/

comment on column ALL_REFRESH.PURGE_OPTION is 'The method for purging the transaction queue after each push'
/

comment on column ALL_REFRESH.PARALLELISM is 'The level of parallelism for transaction propagation'
/

comment on column ALL_REFRESH.HEAP_SIZE is 'The heap size used for transaction propagation'
/

