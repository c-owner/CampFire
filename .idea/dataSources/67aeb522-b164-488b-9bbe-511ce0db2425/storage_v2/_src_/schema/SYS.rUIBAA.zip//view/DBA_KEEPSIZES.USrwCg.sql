create view DBA_KEEPSIZES (TOTSIZE, OWNER, NAME) as
select trunc((sum(parsed_size)+sum(code_size))/1024),
         owner, name
  from dba_object_size
  where type in ('PACKAGE','PROCEDURE','FUNCTION','PACKAGE BODY','TRIGGER',
                 'JAVA SOURCE','JAVA CLASS','JAVA RESOURCE','JAVA DATA')
  group by owner, name
/

