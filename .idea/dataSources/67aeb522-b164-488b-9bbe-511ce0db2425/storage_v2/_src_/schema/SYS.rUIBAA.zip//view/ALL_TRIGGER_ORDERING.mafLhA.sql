create view ALL_TRIGGER_ORDERING
            (TRIGGER_OWNER, TRIGGER_NAME, REFERENCED_TRIGGER_OWNER, REFERENCED_TRIGGER_NAME, ORDERING_TYPE) as
select trigger_owner, trigger_name, referenced_trigger_owner,
  referenced_trigger_name, ordering_type
from sys."_DBA_TRIGGER_ORDERING"
where trigger_owner# = userenv('SCHEMAID') or
      table_owner# = userenv('SCHEMAID') or
      table_obj# in
        (select oa1.obj# from sys.objauth$ oa1 where grantee# in
           (select kzsrorol from x$kzsro)) or
      exists (select null from v$enabledprivs
              where priv_number = -152 /* CREATE ANY TRIGGER */)
/

comment on table ALL_TRIGGER_ORDERING is 'Triggers having FOLLOWS or PRECEDES ordering accessible to the current user'
/

comment on column ALL_TRIGGER_ORDERING.TRIGGER_OWNER is 'Owner of the trigger'
/

comment on column ALL_TRIGGER_ORDERING.REFERENCED_TRIGGER_OWNER is 'Owner of the referenced trigger'
/

comment on column ALL_TRIGGER_ORDERING.REFERENCED_TRIGGER_NAME is 'Name of the referenced trigger'
/

comment on column ALL_TRIGGER_ORDERING.ORDERING_TYPE is 'Type of the ordering between the trigger and the reference trigger'
/

