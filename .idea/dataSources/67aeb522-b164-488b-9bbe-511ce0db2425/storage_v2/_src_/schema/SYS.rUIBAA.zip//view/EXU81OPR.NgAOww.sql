create view EXU81OPR (NAME, OBJID, OWNER, OWNERID, OLEVEL, SQLVER) as
SELECT  o.name, o.obj#, u.name, o.owner#, d.dlevel, sv.sql_version
        FROM    sys.exu81obj o, sys.user$ u, sys.operator$ op,
                sys.exu8ordop d, sys.exu816sqv sv
        WHERE   o.obj# = op.obj# AND
                o.owner# = u.user# AND
                o.obj# = d.obj#(+) AND
                o.spare1 = sv.version# (+)
/

