create view ALL_TAB_PRIVS (GRANTOR, GRANTEE, TABLE_SCHEMA, TABLE_NAME, PRIVILEGE, GRANTABLE, HIERARCHY) as
select ur.name, ue.name, u.name, o.name, tpm.name,
       decode(mod(oa.option$,2), 1, 'YES', 'NO'),
       decode(bitand(oa.option$,2), 2, 'YES', 'NO')
from sys.objauth$ oa, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u, sys.user$ ur,
     sys.user$ ue, table_privilege_map tpm
where oa.obj# = o.obj#
  and oa.grantor# = ur.user#
  and oa.grantee# = ue.user#
  and oa.col# is null
  and u.user# = o.owner#
  and oa.privilege# = tpm.privilege
  and (oa.grantor# = userenv('SCHEMAID') or
       oa.grantee# in (select kzsrorol from x$kzsro) or
       o.owner# = userenv('SCHEMAID'))
/

comment on table ALL_TAB_PRIVS is 'Grants on objects for which the user is the grantor, grantee, owner,
 or an enabled role or PUBLIC is the grantee'
/

comment on column ALL_TAB_PRIVS.GRANTOR is 'Name of the user who performed the grant'
/

comment on column ALL_TAB_PRIVS.GRANTEE is 'Name of the user to whom access was granted'
/

comment on column ALL_TAB_PRIVS.TABLE_SCHEMA is 'Schema of the object'
/

comment on column ALL_TAB_PRIVS.TABLE_NAME is 'Name of the object'
/

comment on column ALL_TAB_PRIVS.PRIVILEGE is 'Table Privilege'
/

comment on column ALL_TAB_PRIVS.GRANTABLE is 'Privilege is grantable'
/

comment on column ALL_TAB_PRIVS.HIERARCHY is 'Privilege is with hierarchy option'
/

