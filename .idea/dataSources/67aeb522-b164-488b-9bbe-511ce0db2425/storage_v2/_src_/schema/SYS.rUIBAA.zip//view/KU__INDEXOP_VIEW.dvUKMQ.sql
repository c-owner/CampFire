create view KU$_INDEXOP_VIEW (OBJ_NUM, OPER_NUM, BIND_NUM, PROPERTY, OPER_OBJ, ARGS) as
select io.obj#, io.oper#, io.bind#, io.property,
         (select value(o) from sys.ku$_schemaobj_view o
          where io.oper#=o.obj_num),
         cast(multiset(select * from sys.oparg$ oa
                       where oa.obj#=io.oper# and oa.bind#=io.bind#
                       order by oa.position
                      ) as ku$_oparg_list_t
             )
  from sys.indop$ io
/

