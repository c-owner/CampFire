create view V_$TIMEZONE_NAMES (TZNAME, TZABBREV) as
select "TZNAME","TZABBREV" from v$timezone_names
/

