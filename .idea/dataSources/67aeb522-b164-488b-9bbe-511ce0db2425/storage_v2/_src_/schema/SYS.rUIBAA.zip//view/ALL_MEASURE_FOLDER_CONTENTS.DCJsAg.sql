create view ALL_MEASURE_FOLDER_CONTENTS (OWNER, MEASURE_FOLDER_NAME, CUBE_OWNER, CUBE_NAME, MEASURE_NAME, ORDER_NUM) as
SELECT
  u.name OWNER,
  o.name MEASURE_FOLDER_NAME,
  cu.name CUBE_OWNER,
  co.name CUBE_NAME,
  m.measure_name MEASURE_NAME,
  mf.order_num ORDER_NUM
FROM
  olap_meas_folder_contents$ mf,
  obj$ o,
  user$ u,
  olap_measures$ m,
  obj$ co,
  user$ cu
WHERE
  mf.measure_folder_obj#=o.obj#
  AND o.owner#=u.user#
  AND mf.object_type = 2 -- MEASURE
  AND mf.object_id = m.measure_id
  AND m.cube_obj# = co.obj#
  AND co.owner# = cu.user#
  AND (co.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or co.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ( exists (select null from v$enabledprivs
                        where priv_number in (-316, -- DELETE ANY MEASURE FOLDER
                                              -317, -- DROP ANY MEASURE FOLDER
                                              -318) -- INSERT ANY MEASURE FOLDER
                        )
              )
            )
/

comment on table ALL_MEASURE_FOLDER_CONTENTS is 'OLAP Measure Folder Contents in the database accessible by the user'
/

comment on column ALL_MEASURE_FOLDER_CONTENTS.OWNER is 'Owner of the OLAP Measure Folder Content'
/

comment on column ALL_MEASURE_FOLDER_CONTENTS.MEASURE_FOLDER_NAME is 'Name of the owning OLAP Measure Folder'
/

comment on column ALL_MEASURE_FOLDER_CONTENTS.CUBE_OWNER is 'Owner of the cube of the OLAP Measure Folder Content'
/

comment on column ALL_MEASURE_FOLDER_CONTENTS.CUBE_NAME is 'Name of the owning cube of the OLAP Measure Folder Content'
/

comment on column ALL_MEASURE_FOLDER_CONTENTS.MEASURE_NAME is 'Name of the owning measure of the OLAP Measure Folder Content'
/

comment on column ALL_MEASURE_FOLDER_CONTENTS.ORDER_NUM is 'Order number of the OLAP Measure Folder Content'
/

