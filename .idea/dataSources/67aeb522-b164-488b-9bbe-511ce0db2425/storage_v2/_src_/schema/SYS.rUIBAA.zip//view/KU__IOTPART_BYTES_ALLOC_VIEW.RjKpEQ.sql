create view KU$_IOTPART_BYTES_ALLOC_VIEW (OBJ_NUM, BYTES_ALLOC) as
select ip.obj#,
            (select b.bytes_alloc from ku$_bytes_alloc_view b
             where b.ts_num = ip.ts#
               and b.file_num = ip.file#
               and b.block_num = ip.block#)
          +decode(bitand(t.property,2048+262144),0,0,   -- add lob storage
            (select sum(b.bytes_alloc)
             from ku$_bytes_alloc_view b, lob$ l,lobfrag$ lf
             where lf.frag#=ip.part# and t.obj#=l.obj# and l.lobj#=lf.parentobj#
               and b.ts_num = lf.ts#
               and b.file_num = lf.file#
               and b.block_num = lf.block#))
  from ind$ i, indpart$ ip, tab$ t
  where i.bo#=t.obj#
    and ip.bo#=i.obj#
    and i.type#=4           -- iot index
/

