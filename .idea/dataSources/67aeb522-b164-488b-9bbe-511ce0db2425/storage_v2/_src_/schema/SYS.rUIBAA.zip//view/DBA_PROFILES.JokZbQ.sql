create view DBA_PROFILES (PROFILE, RESOURCE_NAME, RESOURCE_TYPE, LIMIT) as
select
   n.name, m.name,
   decode(u.type#, 0, 'KERNEL', 1, 'PASSWORD', 'INVALID'),
   decode(u.limit#,
          0, 'DEFAULT',
          2147483647, decode(u.resource#,
                             4, decode(u.type#,
                                       1, 'NULL', 'UNLIMITED'),
                             'UNLIMITED'),
          decode(u.resource#,
                 4, decode(u.type#, 1, o.name, u.limit#),
                 decode(u.type#,
                        0, u.limit#,
                        decode(u.resource#,
                               1, trunc(u.limit#/86400, 4),
                               2, trunc(u.limit#/86400, 4),
                               5, trunc(u.limit#/86400, 4),
                               6, trunc(u.limit#/86400, 4),
                               u.limit#))))
  from sys.profile$ u, sys.profname$ n, sys.resource_map m, sys.obj$ o
  where u.resource# = m.resource#
  and u.type#=m.type#
  and o.obj# (+) = u.limit#
  and n.profile# = u.profile#
/

comment on table DBA_PROFILES is 'Display all profiles and their limits'
/

comment on column DBA_PROFILES.PROFILE is 'Profile name'
/

comment on column DBA_PROFILES.RESOURCE_NAME is 'Resource name'
/

comment on column DBA_PROFILES.LIMIT is 'Limit placed on this resource for this profile'
/

