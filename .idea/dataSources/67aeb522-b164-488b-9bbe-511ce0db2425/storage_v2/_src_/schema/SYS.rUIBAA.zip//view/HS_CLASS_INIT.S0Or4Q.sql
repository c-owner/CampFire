create view HS_CLASS_INIT
            (INIT_VALUE_NAME, INIT_VALUE, INIT_VALUE_TYPE, FDS_CLASS_NAME, FDS_CLASS_INIT_ID, FDS_CLASS_ID) as
select ci.init_value_name, ci.init_value, ci.init_value_type,
       fc.fds_class_name, ci.fds_class_init_id, fc.fds_class_id
from   hs$_class_init ci, hs$_fds_class fc
where  (ci.fds_class_id = fc.fds_class_id)
/

