create view DBA_REPGROUPED_COLUMN (SNAME, ONAME, GROUP_NAME, COLUMN_NAME) as
select distinct
    gc.sname,
    gc.oname,
    gc.group_name,
    gc.column_name
from  system.repcat$_grouped_column gc
/

comment on table DBA_REPGROUPED_COLUMN is 'Columns in the all column groups of replicated tables in the database'
/

comment on column DBA_REPGROUPED_COLUMN.SNAME is 'Owner of replicated object'
/

comment on column DBA_REPGROUPED_COLUMN.ONAME is 'Name of the replicated object'
/

comment on column DBA_REPGROUPED_COLUMN.GROUP_NAME is 'Name of the column group'
/

comment on column DBA_REPGROUPED_COLUMN.COLUMN_NAME is 'Name of the column in the column group'
/

