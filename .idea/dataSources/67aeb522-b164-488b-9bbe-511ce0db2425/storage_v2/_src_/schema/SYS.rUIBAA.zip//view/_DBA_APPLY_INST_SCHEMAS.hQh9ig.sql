create view "_DBA_APPLY_INST_SCHEMAS" (SOURCE_DATABASE, SOURCE_SCHEMA, INSTANTIATION_EXTERNAL_POS) as
select source_db_name, name, inst_external_pos
  from "_DBA_APPLY_SOURCE_SCHEMA"
 where global_flag = 0
/

comment on table "_DBA_APPLY_INST_SCHEMAS" is 'Details about schemas instantiated'
/

comment on column "_DBA_APPLY_INST_SCHEMAS".SOURCE_DATABASE is 'Name of the database where the schemas originated'
/

comment on column "_DBA_APPLY_INST_SCHEMAS".SOURCE_SCHEMA is 'Name of the schemas'
/

comment on column "_DBA_APPLY_INST_SCHEMAS".INSTANTIATION_EXTERNAL_POS is 'Point in time when the schema was instantiated at source'
/

