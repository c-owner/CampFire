create view CATALOG (TNAME, CREATOR, TABLETYPE, REMARKS) as
select tname, creator, tabletype, remarks
  from  syscatalog_
  where creatorid not in (select user# from sys.user$ where name in
        ('SYS','SYSTEM'))
/

