create view DBA_IAS_POSTGEN_STMTS (IAS_TEMPLATE_ID, LINENO, DDL_TEXT) as
select "IAS_TEMPLATE_ID","LINENO","DDL_TEXT" from sys.dba_ias_gen_stmts_exp gs
  where gs.lineno > (select lineno from sys.dba_ias_gen_stmts_exp f
                       where dbms_lob.substr(f.ddl_text,1,1)='0'
                         and dbms_lob.getlength(f.ddl_text) = 1
                         and f.ias_template_id = gs.ias_template_id)
/

