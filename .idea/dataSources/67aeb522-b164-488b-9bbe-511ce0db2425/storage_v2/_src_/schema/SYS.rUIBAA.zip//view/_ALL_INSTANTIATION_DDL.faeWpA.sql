create view "_ALL_INSTANTIATION_DDL" (REFRESH_TEMPLATE_ID, DDL_TEXT, DDL_NUM, PHASE) as
select refresh_template_id, ddl_text, ddl_num, phase
from system.repcat$_instantiation_ddl
/

comment on table "_ALL_INSTANTIATION_DDL" is 'Table containing supplementary DDL to be executed during instantiation.'
/

comment on column "_ALL_INSTANTIATION_DDL".REFRESH_TEMPLATE_ID is 'Primary key of template containing supplementary DDL.'
/

comment on column "_ALL_INSTANTIATION_DDL".DDL_TEXT is 'Supplementary DDL string.'
/

comment on column "_ALL_INSTANTIATION_DDL".DDL_NUM is 'Column for ordering of supplementary DDL.'
/

comment on column "_ALL_INSTANTIATION_DDL".PHASE is 'Phase to execute the DDL string.'
/

