create view DEFSCHEDULE
            (DBLINK, JOB, INTERVAL, NEXT_DATE, LAST_DATE, DISABLED, LAST_TXN_COUNT, LAST_ERROR_NUMBER,
             LAST_ERROR_MESSAGE, CATCHUP, TOTAL_TXN_COUNT, AVG_THROUGHPUT, AVG_LATENCY, TOTAL_BYTES_SENT,
             TOTAL_BYTES_RECEIVED, TOTAL_ROUND_TRIPS, TOTAL_ADMIN_COUNT, TOTAL_ERROR_COUNT, TOTAL_SLEEP_TIME,
             DISABLED_INTERNALLY_SET)
as
SELECT dblink, job, interval, next_date,
         last_date, disabled, last_txn_count, last_error_number,
         last_error_message, catchup,
         total_txn_count,
         avg_throughput,
         avg_latency,
         total_bytes_sent,
         total_bytes_received,
         total_round_trips,
         total_admin_count,
         total_error_count,
         total_sleep_time,
         disabled_internally_set
    FROM sys."_DEFSCHEDULE"
/

comment on table DEFSCHEDULE is 'Information about propagation to different destinations'
/

comment on column DEFSCHEDULE.DBLINK is 'Destination'
/

comment on column DEFSCHEDULE.JOB is 'Number of job that pushes queue'
/

comment on column DEFSCHEDULE.INTERVAL is 'Function used to calculate the next time to push the queue to destination'
/

comment on column DEFSCHEDULE.NEXT_DATE is 'Next date that job is scheduled to be executed'
/

comment on column DEFSCHEDULE.LAST_DATE is 'Last time queue was (attempted to be) pushed to destination'
/

comment on column DEFSCHEDULE.DISABLED is 'Is propagation to destination disabled'
/

comment on column DEFSCHEDULE.LAST_TXN_COUNT is 'Number of transactions pushed during last attempt'
/

comment on column DEFSCHEDULE.LAST_ERROR_NUMBER is 'Oracle error number from last push'
/

comment on column DEFSCHEDULE.LAST_ERROR_MESSAGE is 'Error message from last push'
/

comment on column DEFSCHEDULE.CATCHUP is 'Used to break transaction into pieces'
/

comment on column DEFSCHEDULE.TOTAL_TXN_COUNT is 'Total number of transactions propagated (including error transactions)'
/

comment on column DEFSCHEDULE.AVG_THROUGHPUT is 'Average number of transactions (including errors) propagated per second'
/

comment on column DEFSCHEDULE.AVG_LATENCY is 'Average time in seconds since start of transaction to remote commit'
/

comment on column DEFSCHEDULE.TOTAL_BYTES_SENT is 'Total number of bytes sent over SQL*Net during propagation'
/

comment on column DEFSCHEDULE.TOTAL_BYTES_RECEIVED is 'Total number of bytes received over SQL*Net during propagation'
/

comment on column DEFSCHEDULE.TOTAL_ROUND_TRIPS is 'Total number of SQL*Net round trips during propagation'
/

comment on column DEFSCHEDULE.TOTAL_ADMIN_COUNT is 'Total number of administrative requests'
/

comment on column DEFSCHEDULE.TOTAL_ERROR_COUNT is 'Total number of error transactions propagated'
/

comment on column DEFSCHEDULE.TOTAL_SLEEP_TIME is 'Total time in seconds spent sleeping during propagation'
/

comment on column DEFSCHEDULE.DISABLED_INTERNALLY_SET is 'disabled was set internally for propagation synchronization'
/

