create view DBA_HIST_SHARED_POOL_ADVICE
            (SNAP_ID, DBID, INSTANCE_NUMBER, SHARED_POOL_SIZE_FOR_ESTIMATE, SHARED_POOL_SIZE_FACTOR, ESTD_LC_SIZE,
             ESTD_LC_MEMORY_OBJECTS, ESTD_LC_TIME_SAVED, ESTD_LC_TIME_SAVED_FACTOR, ESTD_LC_LOAD_TIME,
             ESTD_LC_LOAD_TIME_FACTOR, ESTD_LC_MEMORY_OBJECT_HITS)
as
select sp.snap_id, sp.dbid, sp.instance_number,
       shared_pool_size_for_estimate,
       shared_pool_size_factor, estd_lc_size, estd_lc_memory_objects,
       estd_lc_time_saved, estd_lc_time_saved_factor,
       estd_lc_load_time, estd_lc_load_time_factor,
       estd_lc_memory_object_hits
  from wrm$_snapshot sn, WRH$_SHARED_POOL_ADVICE sp
  where     sn.snap_id         = sp.snap_id
        and sn.dbid            = sp.dbid
        and sn.instance_number = sp.instance_number
        and sn.status          = 0
/

comment on table DBA_HIST_SHARED_POOL_ADVICE is 'Shared Pool Advice History'
/

