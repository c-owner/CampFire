create view DBA_REPCOLUMN
            (SNAME, ONAME, TYPE, CNAME, ID, POS, COMPARE_OLD_ON_DELETE, COMPARE_OLD_ON_UPDATE, SEND_OLD_ON_DELETE,
             SEND_OLD_ON_UPDATE, CTYPE, CTYPE_TOID, CTYPE_OWNER, CTYPE_HASHCODE, CTYPE_MOD, DATA_LENGTH, DATA_PRECISION,
             DATA_SCALE, NULLABLE, CHARACTER_SET_NAME, TOP, CHAR_LENGTH, CHAR_USED)
as
select sname, oname, type, cname, id, nvl(pos, lpos), compare_old_on_delete,
          compare_old_on_update, send_old_on_delete, send_old_on_update,
          ctype, ctype_toid, ctype_owner, ctype_hashcode, ctype_mod,
          data_length, data_precision, data_scale, nullable,
          character_set_name, top, char_length, char_used
from repcat_repcolumn_base
/

comment on table DBA_REPCOLUMN is 'Replicated top-level columns (table) sorted alphabetically in ascending order'
/

comment on column DBA_REPCOLUMN.SNAME is 'Name of the object owner'
/

comment on column DBA_REPCOLUMN.ONAME is 'Name of the object'
/

comment on column DBA_REPCOLUMN.TYPE is 'Type of the object'
/

comment on column DBA_REPCOLUMN.CNAME is 'Name of the replicated column'
/

comment on column DBA_REPCOLUMN.ID is 'ID of the replicated column'
/

comment on column DBA_REPCOLUMN.POS is 'Ordering of the replicated column'
/

comment on column DBA_REPCOLUMN.COMPARE_OLD_ON_DELETE is 'Compare the old value of the column in replicated deletes'
/

comment on column DBA_REPCOLUMN.COMPARE_OLD_ON_UPDATE is 'Compare the old value of the column in replicated updates'
/

comment on column DBA_REPCOLUMN.SEND_OLD_ON_DELETE is 'Send the old value of the column in replicated deletes'
/

comment on column DBA_REPCOLUMN.SEND_OLD_ON_UPDATE is 'Send the old value of the column in replicated updates'
/

comment on column DBA_REPCOLUMN.CTYPE is 'Type of the column'
/

comment on column DBA_REPCOLUMN.CTYPE_TOID is 'Type OID of a column of TYPE'
/

comment on column DBA_REPCOLUMN.CTYPE_OWNER is 'Type owner of a column of TYPE'
/

comment on column DBA_REPCOLUMN.CTYPE_HASHCODE is 'Type hashcode of a column of TYPE'
/

comment on column DBA_REPCOLUMN.CTYPE_MOD is 'Datatype modifier of a column'
/

comment on column DBA_REPCOLUMN.DATA_LENGTH is 'Length of the column in bytes'
/

comment on column DBA_REPCOLUMN.DATA_PRECISION is 'Length: decimal digits (NUMBER) or binary digits (FLOAT)'
/

comment on column DBA_REPCOLUMN.DATA_SCALE is 'Digits to right of decimal point in a number'
/

comment on column DBA_REPCOLUMN.NULLABLE is 'Does column allow NULL values?'
/

comment on column DBA_REPCOLUMN.CHARACTER_SET_NAME is 'Name of character set for column, if applicable'
/

comment on column DBA_REPCOLUMN.TOP is 'Top column name for an attribute'
/

comment on column DBA_REPCOLUMN.CHAR_LENGTH is 'The maximum length of the column in characters'
/

comment on column DBA_REPCOLUMN.CHAR_USED is 'C if the width was specified in characters, B if in bytes'
/

