create view USER_CUBE_DIM_MODELS (DIMENSION_NAME, MODEL_NAME, DESCRIPTION) as
SELECT
  do.name DIMENSION_NAME,
  m.model_name MODEL_NAME,
  d.description_value DESCRIPTION
FROM
  olap_models$ m,
  obj$ do,
  (select d.* from olap_descriptions$ d, nls_session_parameters n where
	n.parameter = 'NLS_LANGUAGE'
	and d.description_type = 'Description'
	and d.owning_object_type = 16 --MODEL
	and (d.language = n.value
             or d.language like n.value || '\_%' escape '\')) d
WHERE
  m.owning_obj_type = 11 --DIMENSION
  AND m.owning_obj_id = do.obj#
  AND do.owner# = USERENV('SCHEMAID')
  AND m.model_id = d.owning_object_id(+)
/

comment on table USER_CUBE_DIM_MODELS is 'OLAP Dimension Models in the database accessible to the user'
/

comment on column USER_CUBE_DIM_MODELS.DIMENSION_NAME is 'Name of owning dimension of the OLAP Dimension Model'
/

comment on column USER_CUBE_DIM_MODELS.MODEL_NAME is 'Name of the OLAP Dimension Model'
/

comment on column USER_CUBE_DIM_MODELS.DESCRIPTION is 'Long Description of the OLAP Dimension Model'
/

