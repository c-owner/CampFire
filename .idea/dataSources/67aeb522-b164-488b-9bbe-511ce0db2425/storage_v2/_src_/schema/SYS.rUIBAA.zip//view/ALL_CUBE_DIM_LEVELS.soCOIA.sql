create view ALL_CUBE_DIM_LEVELS (OWNER, DIMENSION_NAME, LEVEL_NAME, DESCRIPTION) as
SELECT
  u.name OWNER,
  o.name DIMENSION_NAME,
  dl.level_name LEVEL_NAME,
  d.description_value DESCRIPTION
FROM
  obj$ o,
  olap_dim_levels$ dl,
  user$ u,
  (select d.* from olap_descriptions$ d, nls_session_parameters n where
	n.parameter = 'NLS_LANGUAGE'
	and d.description_type = 'Description'
	and d.owning_object_type = 12 --DIM_LEVEL
	and (d.language = n.value
             or d.language like n.value || '\_%' escape '\')) d
WHERE
  o.obj#=dl.dim_obj# AND o.owner#=u.user#
  AND d.owning_object_id(+)=dl.level_id
  AND (o.owner# in (userenv('SCHEMAID'), 1)   -- public objects
       or o.obj# in
            ( select obj#  -- directly granted privileges
              from sys.objauth$
              where grantee# in ( select kzsrorol from x$kzsro )
            )
       or   -- user has system privileges
              ( exists (select null from v$enabledprivs
                        where priv_number in (-302, -- ALTER ANY PRIMARY DIMENSION
                                              -304, -- DELETE ANY PRIMARY DIMENSION
                                              -305, -- DROP ANY PRIMARY DIMENSION
                                              -306, -- INSERT ANY PRIMARY DIMENSION
                                              -307) -- SELECT ANY PRIMARY DIMENSION
                        )
              )
            )
/

comment on table ALL_CUBE_DIM_LEVELS is 'OLAP Dimension Levels in the database accessible by the user'
/

comment on column ALL_CUBE_DIM_LEVELS.OWNER is 'Owner of the OLAP Dimension Level'
/

comment on column ALL_CUBE_DIM_LEVELS.DIMENSION_NAME is 'Name of the dimension which owns the OLAP Dimension Level'
/

comment on column ALL_CUBE_DIM_LEVELS.LEVEL_NAME is 'Name of the OLAP Dimension Level'
/

comment on column ALL_CUBE_DIM_LEVELS.DESCRIPTION is 'Long Description of the OLAP Dimension Level'
/

