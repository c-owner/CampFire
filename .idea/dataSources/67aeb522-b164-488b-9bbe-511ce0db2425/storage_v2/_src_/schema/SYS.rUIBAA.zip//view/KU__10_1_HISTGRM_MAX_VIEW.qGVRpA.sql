create view KU$_10_1_HISTGRM_MAX_VIEW (OBJ_NUM, INTCOL_NUM, BUCKET, ENDPOINT, EPVALUE, SPARE1) as
select  obj#, intcol#, 1, maximum, NULL, NULL
   from    sys.hist_head$
   where   bucket_cnt = 1
/

