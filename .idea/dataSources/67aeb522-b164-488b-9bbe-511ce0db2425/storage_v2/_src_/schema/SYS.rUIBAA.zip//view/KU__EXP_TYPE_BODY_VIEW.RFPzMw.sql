create view KU$_EXP_TYPE_BODY_VIEW
            (VERS_MAJOR, VERS_MINOR, BASE_OBJ_NUM, OBJ_NUM, SCHEMA_OBJ, SOURCE_LINES, COMPILER_INFO) as
select /*+ no_merge */
         '1','1',
         o1.obj#,o2.obj#,
         (select value(o) from sys.ku$_edition_schemaobj_view o
                          where o.obj_num=o2.obj#),
       sys.dbms_metadata_util.get_source_lines(o2.name,o2.obj#,o2.type#),
       (select value(c) from sys.ku$_switch_compiler_view c
                 where c.obj_num = o2.obj#)
  from sys.ku$_edition_obj_view o1, sys.ku$_edition_obj_view o2,
       sys.type$ ty, type_misc$ tm
  where o1.type# = 13 and o2.type#=14
    and o1.name=o2.name and o1.owner#=o2.owner#
    and ty.toid=o1.oid$
    and o1.subname is null      /* latest type version */
        /* type$ properties bits:
           8388608=0    - not transient type
           262144=0     - latest type version
           other bits=0 - not system-generated type
        */
    and bitand(ty.properties,8388608+262144+2048+64+16)=0
    and tm.obj#  = o2.obj#
    and bitand(tm.properties,16+32)=0   /* exclude SQLJ type bodies */
         AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o2.owner#, 0) OR
              EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

