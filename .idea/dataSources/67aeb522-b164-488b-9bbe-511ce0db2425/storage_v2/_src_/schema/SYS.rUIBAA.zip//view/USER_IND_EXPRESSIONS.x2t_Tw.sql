create view USER_IND_EXPRESSIONS (INDEX_NAME, TABLE_NAME, COLUMN_EXPRESSION, COLUMN_POSITION) as
select idx.name, base.name, c.default$, ic.pos#
from sys.col$ c, sys.obj$ idx, sys.obj$ base, sys.icol$ ic, sys.ind$ i
where bitand(ic.spare1,1) = 1       /* an expression */
  and (bitand(i.property,1024) = 0) /* not bmji */
  and c.obj# = base.obj#
  and ic.bo# = base.obj#
  and ic.intcol# = c.intcol#
  and base.owner# = userenv('SCHEMAID')
  and base.namespace in (1, 5)
  and ic.obj# = idx.obj#
  and idx.obj# = i.obj#
  and i.type# in (1, 2, 3, 4, 6, 7, 9)
union all
select idx.name, base.name, c.default$, ic.pos#
from sys.col$ c, sys.obj$ idx, sys.obj$ base, sys.icol$ ic, sys.ind$ i
where bitand(ic.spare1,1) = 1       /* an expression */
  and (bitand(i.property,1024) = 0) /* not bmji */
  and c.obj# = base.obj#
  and i.bo# = base.obj#
  and base.owner# != userenv('SCHEMAID')
  and ic.intcol# = c.intcol#
  and idx.owner# = userenv('SCHEMAID')
  and idx.namespace = 4 /* index namespace */
  and ic.obj# = idx.obj#
  and idx.obj# = i.obj#
  and i.type# in (1, 2, 3, 4, 6, 7, 9)
/

comment on table USER_IND_EXPRESSIONS is 'Functional index expressions in user''s indexes and indexes on user''s tables'
/

comment on column USER_IND_EXPRESSIONS.INDEX_NAME is 'Index name'
/

comment on column USER_IND_EXPRESSIONS.TABLE_NAME is 'Table or cluster name'
/

comment on column USER_IND_EXPRESSIONS.COLUMN_EXPRESSION is 'Functional index expression defining the column'
/

comment on column USER_IND_EXPRESSIONS.COLUMN_POSITION is 'Position of column or attribute within index'
/

