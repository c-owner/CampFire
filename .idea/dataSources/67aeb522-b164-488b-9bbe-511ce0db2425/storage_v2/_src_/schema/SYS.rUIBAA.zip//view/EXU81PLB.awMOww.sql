create view EXU81PLB
            (TOBJID, OWNERID, CNAME, LOBNAME, TSNAME, SGFLAGS, PROPERTY, CHUNK, VERSIONP, FLAGS, INIEXTS, EXTSIZE,
             MINEXTS, MAXEXTS, EXTPCT, FLISTS, FREEGRP, PCACHE, COLTYPE, COLTYPFLG)
as
SELECT  l.tobjid, l.ownerid, l.cname, l.lobname, l.tsname, l.sgflags,
                l.property,
                CEIL(l.chunk * (l.blocksize / (
                    SELECT  t$.blocksize
                    FROM    sys.ts$ t$
                    WHERE   t$.ts# = 0))),
                l.versionp, l.flags,
                CEIL(l.iniexts * (l.blocksize / (
                    SELECT  t$.blocksize
                    FROM    sys.ts$ t$
                    WHERE   t$.ts# = 0))),
                CEIL(l.extsize * (l.blocksize / (
                    SELECT  t$.blocksize
                    FROM    sys.ts$ t$
                    WHERE   t$.ts# = 0))),
                l.minexts, l.maxexts, l.extpct, l.flists, l.freegrp, l.pcache,
                l.coltype, l.coltypflg
        FROM    sys.exu9plb l
/

