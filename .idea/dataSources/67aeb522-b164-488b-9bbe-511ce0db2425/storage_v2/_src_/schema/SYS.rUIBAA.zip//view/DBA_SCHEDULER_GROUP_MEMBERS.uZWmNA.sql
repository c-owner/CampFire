create view DBA_SCHEDULER_GROUP_MEMBERS (OWNER, GROUP_NAME, MEMBER_NAME) as
SELECT wgm.owner, wgm.group_name,wgm.cred || wgm.mem_name
FROM
(SELECT u.name owner, o.name group_name, wg.member_oid2 member_oid2,
        decode(member_oid2, null,null,'"' || cmu.name || '"."' || cmo.name || '"@') cred,
        decode(wmu.name || '"' || substr(wmo.name,1,12), 'SYS"SCHED$_LOCAL', 'LOCAL',
          '"'  || wmu.name || '"."' || wmo.name || '"' )mem_name
FROM user$ u, obj$ o, scheduler$_window_group w, scheduler$_wingrp_member wg,
     user$ wmu, obj$ wmo, user$ cmu, obj$ cmo
WHERE w.obj# = wg.oid AND w.obj# = o.obj# AND o.owner# = u.user# AND
  wg.member_oid = wmo.obj# AND wmo.owner# = wmu.user# AND
  cmo.obj#(+) = wg.member_oid2 AND cmo.owner# = cmu.user#(+) )wgm
/

comment on table DBA_SCHEDULER_GROUP_MEMBERS is 'Members of all scheduler object groups in the database'
/

comment on column DBA_SCHEDULER_GROUP_MEMBERS.OWNER is 'Owner of the group'
/

comment on column DBA_SCHEDULER_GROUP_MEMBERS.GROUP_NAME is 'Name of the group'
/

comment on column DBA_SCHEDULER_GROUP_MEMBERS.MEMBER_NAME is 'Name of the member of this group'
/

