create view USER_REPKEY_COLUMNS (SNAME, ONAME, COL) as
select r.sname, r.oname, r.col
from sys.dba_repkey_columns r, user_users u
where r.sname = u.username
/

comment on table USER_REPKEY_COLUMNS is 'Primary columns for a table using column-level replication'
/

comment on column USER_REPKEY_COLUMNS.SNAME is 'Schema containing table'
/

comment on column USER_REPKEY_COLUMNS.ONAME is 'Name of the table'
/

comment on column USER_REPKEY_COLUMNS.COL is 'Column in the table'
/

