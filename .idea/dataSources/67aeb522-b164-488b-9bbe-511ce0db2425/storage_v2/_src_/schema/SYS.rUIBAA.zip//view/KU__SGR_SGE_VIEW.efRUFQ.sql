create view KU$_SGR_SGE_VIEW (OBJ_NUM, GRANTOR_NUM, GRANTEE_NUM, COLNUM, WGO, MIN_SEQUENCE) as
select unique g.obj#, g.grantor#, g.grantee#, g.col#,
         NVL(g.option$,0),
         (select min(g2.sequence#) from objauth$ g2
          where g2.obj# = g.obj# and g2.grantor# = g.grantor# and
                g2.grantee# = g.grantee# and
               ((g2.col# = g.col#) or (g2.col# is null and g.col# is null)))
  from objauth$ g
/

