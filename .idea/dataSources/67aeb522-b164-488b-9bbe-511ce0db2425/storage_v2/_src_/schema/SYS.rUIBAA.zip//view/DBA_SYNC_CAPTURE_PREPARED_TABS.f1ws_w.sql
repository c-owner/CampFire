create view DBA_SYNC_CAPTURE_PREPARED_TABS (TABLE_OWNER, TABLE_NAME, SCN, TIMESTAMP) as
select u.name, o.name, co.ignore_scn, co.timestamp
  from obj$ o, user$ u, streams$_prepare_object co
  where o.obj# = co.obj# and o.owner# = u.user#
    and co.cap_type = 1
/

comment on table DBA_SYNC_CAPTURE_PREPARED_TABS is 'All tables prepared for synchronous capture instantiation'
/

comment on column DBA_SYNC_CAPTURE_PREPARED_TABS.TABLE_OWNER is 'Owner of the table prepared for synchronous capture instantiation'
/

comment on column DBA_SYNC_CAPTURE_PREPARED_TABS.TABLE_NAME is 'Name of the table prepared for synchronous capture instantiation'
/

comment on column DBA_SYNC_CAPTURE_PREPARED_TABS.SCN is 'SCN from which changes can be captured'
/

comment on column DBA_SYNC_CAPTURE_PREPARED_TABS.TIMESTAMP is 'Time at which the table was ready to be instantiated'
/

