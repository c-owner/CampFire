create view DBA_HIST_RSRC_CONSUMER_GROUP
            (SNAP_ID, DBID, INSTANCE_NUMBER, SEQUENCE#, CONSUMER_GROUP_ID, CONSUMER_GROUP_NAME, REQUESTS, CPU_WAIT_TIME,
             CPU_WAITS, CONSUMED_CPU_TIME, YIELDS, ACTIVE_SESS_LIMIT_HIT, UNDO_LIMIT_HIT, SWITCHES_IN_CPU_TIME,
             SWITCHES_OUT_CPU_TIME, SWITCHES_IN_IO_MEGABYTES, SWITCHES_OUT_IO_MEGABYTES, SWITCHES_IN_IO_REQUESTS,
             SWITCHES_OUT_IO_REQUESTS, SQL_CANCELED, ACTIVE_SESS_KILLED, IDLE_SESS_KILLED, IDLE_BLKR_SESS_KILLED,
             QUEUED_TIME, QUEUE_TIME_OUTS, IO_SERVICE_TIME, IO_SERVICE_WAITS, SMALL_READ_MEGABYTES,
             SMALL_WRITE_MEGABYTES, LARGE_READ_MEGABYTES, LARGE_WRITE_MEGABYTES, SMALL_READ_REQUESTS,
             SMALL_WRITE_REQUESTS, LARGE_READ_REQUESTS, LARGE_WRITE_REQUESTS, PQS_QUEUED, PQ_QUEUED_TIME,
             PQ_QUEUE_TIME_OUTS, PQS_COMPLETED, PQ_SERVERS_USED, PQ_ACTIVE_TIME)
as
select
  cg.snap_id,
  cg.dbid,
  cg.instance_number,
  cg.sequence#,
  cg.consumer_group_id,
  cg.consumer_group_name,
  cg.requests,
  cg.cpu_wait_time,
  cg.cpu_waits,
  cg.consumed_cpu_time,
  cg.yields,
  cg.active_sess_limit_hit,
  cg.undo_limit_hit,
  cg.switches_in_cpu_time,
  cg.switches_out_cpu_time,
  cg.switches_in_io_megabytes,
  cg.switches_out_io_megabytes,
  cg.switches_in_io_requests,
  cg.switches_out_io_requests,
  cg.sql_canceled,
  cg.active_sess_killed,
  cg.idle_sess_killed,
  cg.idle_blkr_sess_killed,
  cg.queued_time,
  cg.queue_time_outs,
  cg.io_service_time,
  cg.io_service_waits,
  cg.small_read_megabytes,
  cg.small_write_megabytes,
  cg.large_read_megabytes,
  cg.large_write_megabytes,
  cg.small_read_requests,
  cg.small_write_requests,
  cg.large_read_requests,
  cg.large_write_requests,
  nvl(cg.pqs_queued, 0),
  nvl(cg.pq_queued_time, 0),
  nvl(cg.pq_queue_time_outs, 0),
  nvl(cg.pqs_completed, 0),
  nvl(cg.pq_servers_used, 0),
  nvl(cg.pq_active_time, 0)
  from wrm$_snapshot sn, WRH$_RSRC_CONSUMER_GROUP cg
  where     sn.snap_id         = cg.snap_id
        and sn.dbid            = cg.dbid
        and sn.instance_number = cg.instance_number
        and sn.status          = 0
/

comment on table DBA_HIST_RSRC_CONSUMER_GROUP is 'Historical resource consumer group statistics'
/

