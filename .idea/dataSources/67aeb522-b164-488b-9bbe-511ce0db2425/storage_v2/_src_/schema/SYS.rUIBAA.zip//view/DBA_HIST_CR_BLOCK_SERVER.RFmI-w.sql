create view DBA_HIST_CR_BLOCK_SERVER
            (SNAP_ID, DBID, INSTANCE_NUMBER, CR_REQUESTS, CURRENT_REQUESTS, DATA_REQUESTS, UNDO_REQUESTS, TX_REQUESTS,
             CURRENT_RESULTS, PRIVATE_RESULTS, ZERO_RESULTS, DISK_READ_RESULTS, FAIL_RESULTS, FAIRNESS_DOWN_CONVERTS,
             FAIRNESS_CLEARS, FREE_GC_ELEMENTS, FLUSHES, FLUSHES_QUEUED, FLUSH_QUEUE_FULL, FLUSH_MAX_TIME, LIGHT_WORKS,
             ERRORS)
as
select crb.snap_id, crb.dbid, crb.instance_number,
       cr_requests, current_requests,
       data_requests, undo_requests, tx_requests,
       current_results, private_results, zero_results,
       disk_read_results, fail_results,
       fairness_down_converts, fairness_clears, free_gc_elements,
       flushes, flushes_queued, flush_queue_full, flush_max_time,
       light_works, errors
  from wrm$_snapshot sn, WRH$_CR_BLOCK_SERVER crb
  where     sn.snap_id         = crb.snap_id
        and sn.dbid            = crb.dbid
        and sn.instance_number = crb.instance_number
        and sn.status          = 0
/

comment on table DBA_HIST_CR_BLOCK_SERVER is 'Consistent Read Block Server Historical Statistics'
/

