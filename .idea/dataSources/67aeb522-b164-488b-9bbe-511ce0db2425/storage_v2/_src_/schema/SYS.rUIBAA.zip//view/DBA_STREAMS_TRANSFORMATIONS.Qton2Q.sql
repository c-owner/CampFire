create view DBA_STREAMS_TRANSFORMATIONS
            (RULE_OWNER, RULE_NAME, TRANSFORM_TYPE, FROM_SCHEMA_NAME, TO_SCHEMA_NAME, FROM_TABLE_NAME, TO_TABLE_NAME,
             SCHEMA_NAME, TABLE_NAME, FROM_COLUMN_NAME, TO_COLUMN_NAME, COLUMN_NAME, COLUMN_VALUE, COLUMN_TYPE,
             COLUMN_FUNCTION, VALUE_TYPE, USER_FUNCTION_NAME, SUBSETTING_OPERATION, DML_CONDITION, DECLARATIVE_TYPE,
             PRECEDENCE, STEP_NUMBER)
as
select rule_owner, rule_name, 'DECLARATIVE TRANSFORMATION',
  from_schema_name, to_schema_name, from_table_name, to_table_name,
  schema_name, table_name, from_column_name, to_column_name,
  column_name, column_value, sys.anydata.gettypename(column_value),
  column_function,
  decode(value_type, 1, 'OLD',
                     2, 'NEW',
                     3, '*'),
  NULL, NULL, NULL,  decode(declarative_type, 0, 'KEEP COLUMNS',
                                              1, 'DELETE COLUMN',
                                              2, 'RENAME COLUMN',
                                              3, 'ADD COLUMN',
                                              4, 'RENAME TABLE',
                                              5, 'RENAME SCHEMA'),
  precedence, step_number
  from "_DBA_STREAMS_TRANSFORMATIONS" t
union all
select rule_owner, rule_name, 'SUBSET RULE', NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  decode(subsetting_operation, 1, 'INSERT',
                               2, 'UPDATE',
                               3, 'DELETE'),
  dml_condition, NULL, NULL, NULL
  from sys.streams$_rules where subsetting_operation is not NULL
union all
select rule_owner, rule_name, 'CUSTOM TRANSFORMATION', NULL, NULL, NULL, NULL,
  NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  transform_function_name, NULL, NULL, NULL, NULL, NULL
  from "_DBA_STREAMS_TRANSFM_FUNCTION"
/

comment on table DBA_STREAMS_TRANSFORMATIONS is 'Transformations defined on rules'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.RULE_OWNER is 'Owner of the rule which has an associated transformation'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.RULE_NAME is 'Name of the rule which has an associated transformation'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.TRANSFORM_TYPE is 'The type of transformation'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.FROM_SCHEMA_NAME is 'The schema to be renamed'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.TO_SCHEMA_NAME is 'The new schema name'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.FROM_TABLE_NAME is 'The table to be renamed'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.TO_TABLE_NAME is 'The new table name'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.SCHEMA_NAME is 'The schema of the column to be modified'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.TABLE_NAME is 'The table of the column to be modified'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.FROM_COLUMN_NAME is 'The column to rename'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.TO_COLUMN_NAME is 'The new column name'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.COLUMN_NAME is 'The column to add or delete'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.COLUMN_VALUE is 'The value of the column to add'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.COLUMN_TYPE is 'The type of the new column'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.COLUMN_FUNCTION is 'The name of the default function used to add a column'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.USER_FUNCTION_NAME is 'The name of the user-defined transformation function to run '
/

comment on column DBA_STREAMS_TRANSFORMATIONS.SUBSETTING_OPERATION is 'DML operation for row subsetting'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.DML_CONDITION is 'Row subsetting condition'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.DECLARATIVE_TYPE is 'The type of declarative transformation to run'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.PRECEDENCE is 'Execution order relative to other declarative transformations on the same step_number'
/

comment on column DBA_STREAMS_TRANSFORMATIONS.STEP_NUMBER is 'The order that this transformation should be executed'
/

