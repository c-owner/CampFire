create view "_DBA_APPLY_CHANGE_HANDLERS"
            (CHANGE_TABLE_OWNER, CHANGE_TABLE_NAME, SOURCE_TABLE_OWNER, SOURCE_TABLE_NAME, HANDLER_NAME, CAPTURE_VALUES,
             APPLY_NAME, OPERATION_NAME, CREATION_TIME, MODIFICATION_TIME)
as
select change_table_owner, change_table_name, source_table_owner,
         source_table_name, handler_name, capture_values,
         apply_name, operation, creation_time, modification_time
  from   apply$_change_handlers
/

