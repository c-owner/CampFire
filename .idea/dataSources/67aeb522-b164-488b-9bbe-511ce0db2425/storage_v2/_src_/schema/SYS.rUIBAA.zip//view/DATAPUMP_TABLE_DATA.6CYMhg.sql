create view DATAPUMP_TABLE_DATA (HET_TYPE, OBJECT_PATH, SEQ_NUM) as
select htype,name,seq#
 from sys.metanametrans$
 where properties!=0
 and name like '%/TABLE_DATA'
 and name not like '%INDEX%'
/

