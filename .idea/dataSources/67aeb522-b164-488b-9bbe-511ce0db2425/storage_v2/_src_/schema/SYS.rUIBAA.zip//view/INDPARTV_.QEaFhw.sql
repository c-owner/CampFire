create view INDPARTV$
            (OBJ#, DATAOBJ#, BO#, PART#, HIBOUNDLEN, HIBOUNDVAL, FLAGS, TS#, FILE#, BLOCK#, PCTFREE$, PCTTHRES$,
             INITRANS, MAXTRANS, ANALYZETIME, SAMPLESIZE, ROWCNT, BLEVEL, LEAFCNT, DISTKEY, LBLKKEY, DBLKKEY, CLUFAC,
             SPARE1, SPARE2, SPARE3, INCLCOL, PHYPART#)
as
select obj#, dataobj#, bo#,
          row_number() over (partition by bo# order by part#),
          hiboundlen, hiboundval, flags, ts#, file#, block#,
          pctfree$, pctthres$, initrans, maxtrans, analyzetime, samplesize,
          rowcnt, blevel, leafcnt, distkey, lblkkey, dblkkey, clufac, spare1,
          spare2, spare3, inclcol, part#
from indpart$
/

