create view V_$OBSOLETE_PARAMETER (NAME, ISSPECIFIED) as
select "NAME","ISSPECIFIED" from v$obsolete_parameter
/

