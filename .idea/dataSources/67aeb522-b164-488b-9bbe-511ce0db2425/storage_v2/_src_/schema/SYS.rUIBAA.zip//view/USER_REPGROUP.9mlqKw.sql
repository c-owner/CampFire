create view USER_REPGROUP (SNAME, MASTER, STATUS, SCHEMA_COMMENT, GNAME, FNAME, RPC_PROCESSING_DISABLED, OWNER) as
select r.sname, r.master, r.status, r.schema_comment, r.sname, r.fname,
       r.rpc_processing_disabled, r.gowner
from repcat_repcat r, user_users u
where (r.sname = u.username)
   or r.gowner in
      (select name from user$
        where user# = userenv('SCHEMAID') and type# = 1)
/

comment on table USER_REPGROUP is 'Replication information about the current user'
/

comment on column USER_REPGROUP.SNAME is 'OBSOLETE COLUMN: Name of the user'
/

comment on column USER_REPGROUP.MASTER is 'Is the site a master site'
/

comment on column USER_REPGROUP.STATUS is 'If site is master, the master''s status'
/

comment on column USER_REPGROUP.SCHEMA_COMMENT is 'User description of the replicated object group'
/

comment on column USER_REPGROUP.GNAME is 'Name of the replicated object group'
/

comment on column USER_REPGROUP.FNAME is 'Flavor name'
/

comment on column USER_REPGROUP.RPC_PROCESSING_DISABLED is 'Whether this site disables processing of replication RPC'
/

comment on column USER_REPGROUP.OWNER is 'Owner of the replicated object group'
/

