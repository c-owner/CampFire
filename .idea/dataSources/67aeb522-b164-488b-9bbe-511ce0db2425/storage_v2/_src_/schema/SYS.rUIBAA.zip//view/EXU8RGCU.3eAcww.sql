create view EXU8RGCU (OWNER, OWNERID, CHILD, TYPE, REFGROUP) as
SELECT  "OWNER","OWNERID","CHILD","TYPE","REFGROUP"
        FROM    sys.exu8rgc
        WHERE   UID = ownerid
/

