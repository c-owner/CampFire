create view SYSCATALOG (TNAME, CREATOR, TABLETYPE, REMARKS) as
select tname, creator, tabletype, remarks
  from syscatalog_
/

