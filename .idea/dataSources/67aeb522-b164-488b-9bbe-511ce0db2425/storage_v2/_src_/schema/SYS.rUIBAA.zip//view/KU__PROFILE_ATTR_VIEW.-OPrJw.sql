create view KU$_PROFILE_ATTR_VIEW (PROFILE_ID, RESOURCE_NUM, RESNAME, TYPE_NUM, LIMIT_NUM) as
select  p.profile#,
          p.resource#,
          r.name,
          p.type#,
          p.limit#
  from sys.resource_map r, sys.profile$ p
  where p.resource# = r.resource# and p.type# = r.type#
/

