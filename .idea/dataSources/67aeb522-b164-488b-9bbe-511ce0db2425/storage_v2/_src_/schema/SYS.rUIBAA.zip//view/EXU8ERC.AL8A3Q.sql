create view EXU8ERC (RESOURCE_NAME, UNIT_COST) as
SELECT  m.name, c.cost
        FROM    sys.resource_cost$ c, sys.resource_map m
        WHERE   c.resource# = m.resource# AND
                m.type# = 0 AND
                c.resource# IN (2, 4, 7, 8)
/

