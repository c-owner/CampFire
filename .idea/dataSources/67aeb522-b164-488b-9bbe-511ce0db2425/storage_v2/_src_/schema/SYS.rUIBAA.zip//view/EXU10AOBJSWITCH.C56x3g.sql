create view EXU10AOBJSWITCH (OBJID, NLSLENSEM, OPTLEVEL, CODETYPE, DEBUG, WARNINGS) as
SELECT  a.obj#, a.value, b.value, c.value, d.value, e.value
        FROM    sys.settings$ a, sys.settings$ b, sys.settings$ c,
                sys.settings$ d, sys.settings$ e, sys.obj$ o
        WHERE   o.obj#  = a.obj# AND
                a.obj#  = b.obj# AND
                b.obj#  = c.obj# AND
                c.obj#  = d.obj# AND
                d.obj#  = e.obj# AND
                a.param = 'nls_length_semantics'         AND
                b.param = 'plsql_optimize_level'         AND
                c.param = 'plsql_code_type'              AND
                d.param = 'plsql_debug'                  AND
                e.param = 'plsql_warnings'               AND
                (UID IN (o.owner#, 0) OR
                 EXISTS (
                    SELECT  role
                    FROM    sys.session_roles
                    WHERE   role = 'SELECT_CATALOG_ROLE'))
/

