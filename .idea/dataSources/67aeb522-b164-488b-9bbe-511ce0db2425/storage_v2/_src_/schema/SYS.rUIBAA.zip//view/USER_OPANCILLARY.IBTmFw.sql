create view USER_OPANCILLARY (OWNER, OPERATOR_NAME, BINDING#, PRIMOP_OWNER, PRIMOP_NAME, PRIMOP_BIND#) as
select distinct u.name, o.name, a.bind#, u1.name, o1.name, a1.primbind#
from   sys.user$ u, sys.obj$ o, sys.opancillary$ a, sys.user$ u1, sys.obj$ o1,
       sys.opancillary$ a1
where  a.obj#=o.obj# and o.owner#=u.user#   AND
       a1.primop#=o1.obj# and o1.owner#=u1.user# and a.obj#=a1.obj#
       and o.owner#=userenv('SCHEMAID')
/

comment on table USER_OPANCILLARY is 'All ancillary opertors defined by user'
/

comment on column USER_OPANCILLARY.OWNER is 'Owner of ancillary operator'
/

comment on column USER_OPANCILLARY.OPERATOR_NAME is 'Name of ancillary operator'
/

comment on column USER_OPANCILLARY.BINDING# is 'Binding number of ancillary operator'
/

comment on column USER_OPANCILLARY.PRIMOP_OWNER is 'Owner of primary operator'
/

comment on column USER_OPANCILLARY.PRIMOP_NAME is 'Name of primary operator'
/

comment on column USER_OPANCILLARY.PRIMOP_BIND# is 'Binding number of primary operator'
/

