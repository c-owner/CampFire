create view EXU8PSTC (OWNER, OWNERID, TNAME, TOBJID, CALLORDER, CALLARG, OBJTYPE, USRARG, PROPERTY) as
SELECT  "OWNER","OWNERID","TNAME","TOBJID","CALLORDER","CALLARG","OBJTYPE","USRARG","PROPERTY"
        FROM    sys.exu8pst
        WHERE   (ownerid, tname) IN (
                    SELECT  ownerid, name
                    FROM    sys.exu8tabc)
/

