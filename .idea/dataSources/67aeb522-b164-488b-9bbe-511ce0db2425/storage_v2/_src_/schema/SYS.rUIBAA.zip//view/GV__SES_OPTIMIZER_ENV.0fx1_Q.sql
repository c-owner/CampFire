create view GV_$SES_OPTIMIZER_ENV (INST_ID, SID, ID, NAME, SQL_FEATURE, ISDEFAULT, VALUE) as
select "INST_ID","SID","ID","NAME","SQL_FEATURE","ISDEFAULT","VALUE" from gv$ses_optimizer_env
/

