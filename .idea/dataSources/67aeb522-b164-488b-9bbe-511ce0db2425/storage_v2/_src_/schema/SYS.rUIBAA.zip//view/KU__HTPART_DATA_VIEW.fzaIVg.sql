create view KU$_HTPART_DATA_VIEW
            (VERS_MAJOR, VERS_MINOR, OBJ_NUM, DATAOBJ_NUM, NAME, PART_NAME, PARTTYPE, PROPERTY, TRIGFLAG, XMLTYPE_FMTS,
             XMLSCHEMACOLS, XML_OUTOFLINE, LONGCOL, NFT_VARRAY, NONSCOPED_REF, TSTZ_COLS, SCHEMA_OBJ, TS_NAME,
             BLOCKSIZE, BYTES_ALLOC, BASE_OBJ, DOMIDX_OBJ, ANC_OBJ, UNLOAD_METHOD, ET_PARALLEL, FGAC, REFPAR_LEVEL)
as
select '1','2',
         tp.obj#, tp.obj#,
         o.subname,
         NULL,
         po.parttype,
         t.property,
         t.trigflag,
         dbms_metadata_util.get_xmltype_fmts(t.obj#),
         decode((select 1 from dual where
                 (exists (select q.obj# from sys.opqtype$ q
                          where q.obj#=t.obj#
                          and q.type=1                        /* xmltype col */
                          and bitand(q.flags,2+64)!=0))),       /* CSX or SB */
                1,'Y','N'),
         decode((select count(*)                      /* outofline xml table */
                    from sys.opqtype$ q
                    where q.obj# = t.obj# and
                          bitand(q.flags, 32) = 32 ),
                1,'Y','N'),
         'N',     /* partitioned table cannot have column with LONG datatype */
         decode((select count(*) from sys.type$ ty, sys.coltype$ ct
                 where ty.toid=ct.toid and ty.version#=ct.version#
                 and ct.obj#=t.obj#
                 /* 0x00008000 =   32768 = contains varray attribute */
                 /* 0x00100000 = 1048576 = has embedded non final type */
                 and bitand(ty.properties,1081344)=1081344),
                 0,'N','Y'),
         decode((select count(*) from sys.refcon$ rf, sys.col$ c
                 where c.obj#=rf.obj# and c.intcol#=rf.intcol#
                 and c.obj#=t.obj#
                 and bitand(rf.reftyp,1)=0),            /* ref is non-scoped */
                 0,'N','Y'),
         'N',                              /* default 'has_tstz_cols' to 'N' */
         value(o),
         ts.name, ts.blocksize, b.bytes_alloc,
         value(bo),
         -- if this is a secondary table, get domidx obj and ancestor obj
         decode(bitand(bo.flags, 16), 16,
           (select value(oo) from ku$_schemaobj_view oo, secobj$ s
              where bo.obj_num=s.secobj#
                and oo.obj_num=s.obj#
                and rownum < 2),
           null),
         decode(bitand(bo.flags, 16), 16,
           (select value(oo) from ku$_schemaobj_view oo, ind$ i, secobj$ s
              where bo.obj_num=s.secobj#
                and i.obj#=s.obj#
                and oo.obj_num=i.bo#
                and rownum < 2),
           null),
         um.unload_method,
         um.et_parallel,
         (select count(*) from rls$ r
          where r.obj#=t.obj# and r.enable_flag=1 and bitand(r.stmt_type,1)=1),
         sys.dbms_metadata_util.ref_par_level(bo.obj_num,t.property)
  from ku$_htpart_bytes_alloc_view b,ku$_schemaobj_view o,
       ku$_schemaobjnum_view bo, ku$_unload_method_view um,
       tab$ t, tabpart$ tp, ts$ ts, partobj$ po
  where tp.obj# = o.obj_num
        AND bo.obj_num = po.obj#
        AND t.obj#=tp.bo#
        AND t.obj# = um.obj_num
        AND bitand(t.property, 32+64+128+256+512+8192) = 32
                                                /* partitioned (32)       */
                                                /* but not IOT            */
                                                /* or nested table        */
        AND bitand(t.flags,536870912)=0         /* not an IOT mapping table */
        AND tp.ts# = ts.ts#
        AND b.obj_num=tp.obj#
        AND bo.obj_num=tp.bo#
        AND (bitand(bo.flags,16)!=16
             OR sys.dbms_metadata.oktoexp_2ndary_table(bo.obj_num)=1)
        AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0) OR
                EXISTS ( SELECT * FROM sys.session_roles
                        WHERE role='SELECT_CATALOG_ROLE' ))
/

