create view DBA_HIST_RSRC_PLAN
            (SNAP_ID, DBID, INSTANCE_NUMBER, SEQUENCE#, START_TIME, END_TIME, PLAN_ID, PLAN_NAME, CPU_MANAGED,
             PARALLEL_EXECUTION_MANAGED)
as
select
  pl.snap_id,
  pl.dbid,
  pl.instance_number,
  pl.sequence#,
  pl.start_time,
  pl.end_time,
  pl.plan_id,
  pl.plan_name,
  pl.cpu_managed,
  nvl(pl.parallel_execution_managed, 'OFF')
  from wrm$_snapshot sn, WRH$_RSRC_PLAN pl
  where     sn.snap_id         = pl.snap_id
        and sn.dbid            = pl.dbid
        and sn.instance_number = pl.instance_number
        and sn.status          = 0
/

comment on table DBA_HIST_RSRC_PLAN is 'Historical resource plan statistics'
/

