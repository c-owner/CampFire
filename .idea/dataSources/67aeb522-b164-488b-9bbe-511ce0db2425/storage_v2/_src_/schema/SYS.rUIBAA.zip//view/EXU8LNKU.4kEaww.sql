create view EXU8LNKU (OWNER, OWNERID, NAME, USER$, PASSWD, HOST, PUBLIC$) as
SELECT  "OWNER","OWNERID","NAME","USER$","PASSWD","HOST","PUBLIC$"
        FROM    sys.exu8lnk
        WHERE   ownerid = UID
/

