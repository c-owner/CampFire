create view V_$ARCHIVE_GAP (THREAD#, LOW_SEQUENCE#, HIGH_SEQUENCE#) as
select "THREAD#","LOW_SEQUENCE#","HIGH_SEQUENCE#" from v$archive_gap
/

