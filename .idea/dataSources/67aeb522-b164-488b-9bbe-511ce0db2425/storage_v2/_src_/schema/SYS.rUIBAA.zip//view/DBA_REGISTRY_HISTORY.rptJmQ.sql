create view DBA_REGISTRY_HISTORY (ACTION_TIME, ACTION, NAMESPACE, VERSION, ID, COMMENTS) as
SELECT action_time, action, namespace, version, id, comments
FROM registry$history
/

