create view V_$LOGSTDBY_STATS (NAME, VALUE) as
select "NAME","VALUE" from v$logstdby_stats
/

