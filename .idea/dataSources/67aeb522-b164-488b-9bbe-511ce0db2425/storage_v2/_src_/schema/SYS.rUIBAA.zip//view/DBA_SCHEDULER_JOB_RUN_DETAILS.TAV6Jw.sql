create view DBA_SCHEDULER_JOB_RUN_DETAILS
            (LOG_ID, LOG_DATE, OWNER, JOB_NAME, JOB_SUBNAME, STATUS, ERROR#, REQ_START_DATE, ACTUAL_START_DATE,
             RUN_DURATION, INSTANCE_ID, SESSION_ID, SLAVE_PID, CPU_USED, CREDENTIAL_OWNER, CREDENTIAL_NAME,
             DESTINATION_OWNER, DESTINATION, ADDITIONAL_INFO)
as
(SELECT
     j.LOG_ID, j.LOG_DATE, e.OWNER,
     DECODE(instr(e.NAME,'"'),0, e.NAME,substr(e.NAME,1,instr(e.NAME,'"')-1)),
     DECODE(instr(e.NAME,'"'),0,NULL,substr(e.NAME,instr(e.NAME,'"')+1)),
     e.STATUS, j.ERROR#, j.REQ_START_DATE, j.START_DATE, j.RUN_DURATION,
     j.INSTANCE_ID, j.SESSION_ID, j.SLAVE_PID, j.CPU_USED,
     decode(e.credential, NULL, NULL,
        substr(e.credential, 1, instr(e.credential, '"')-1)),
     decode(e.credential, NULL, NULL,
        substr(e.credential, instr(e.credential, '"')+1,
           length(e.credential) - instr(e.credential, '"'))),
     decode(bitand(e.flags, 1), 0, NULL,
        substr(e.destination, 1, instr(e.destination, '"')-1)),
     decode(bitand(e.flags, 1), 0, e.destination,
        substr(e.destination, instr(e.destination, '"')+1,
           length(e.destination) - instr(e.destination, '"'))),
     j.ADDITIONAL_INFO
   FROM scheduler$_job_run_details j, scheduler$_event_log e
   WHERE j.log_id = e.log_id and e.dbid is null
   AND e.type# = 66)
/

comment on table DBA_SCHEDULER_JOB_RUN_DETAILS is 'The details of a job run'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.LOG_ID is 'The unique id of the log entry. Foreign key on entry in dba_scheduler_job_log'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.LOG_DATE is 'The date of the log entry'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.OWNER is 'The owner of the scheduler job'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.JOB_NAME is 'The name of the scheduler job'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.JOB_SUBNAME is 'The subname of the scheduler job (for a chain step job)'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.STATUS is 'The status of the job run'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.ERROR# is 'The error number in the case of error'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.REQ_START_DATE is 'The requested start date of the job run'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.ACTUAL_START_DATE is 'The actual date the job ran'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.RUN_DURATION is 'The duration that the job ran'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.INSTANCE_ID is 'The id of the instance on which the job ran'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.SESSION_ID is 'The session id of the job run'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.SLAVE_PID is 'The process id of the slave on which the job ran'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.CPU_USED is 'The amount of cpu used for this job run'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.CREDENTIAL_OWNER is 'Owner of the credential used for this remote job run'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.CREDENTIAL_NAME is 'Name of the credential used for this remote job run'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.DESTINATION_OWNER is 'Owner of destination object used in remote run or NULL if no object used'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.DESTINATION is 'The destination for a remote job run'
/

comment on column DBA_SCHEDULER_JOB_RUN_DETAILS.ADDITIONAL_INFO is 'Additional information on the job run, if applicable'
/

