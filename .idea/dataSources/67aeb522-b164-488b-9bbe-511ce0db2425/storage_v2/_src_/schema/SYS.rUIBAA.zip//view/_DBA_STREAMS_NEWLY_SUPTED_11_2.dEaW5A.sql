create view "_DBA_STREAMS_NEWLY_SUPTED_11_2" (OWNER, TABLE_NAME, REASON, COMPATIBLE, STR_COMPAT) as
select owner, table_name, reason, '11.2', 112
    from "_DBA_STREAMS_UNSUPPORTED_11_1" o
    where not exists
      (select 1 from "_DBA_STREAMS_UNSUPPORTED_11_2" i
         where i.owner = o.owner
           and i.table_name = o.table_name)
/

