create view DBA_SEGMENTS_OLD
            (OWNER, SEGMENT_NAME, PARTITION_NAME, SEGMENT_TYPE, TABLESPACE_NAME, HEADER_FILE, HEADER_BLOCK, BYTES,
             BLOCKS, EXTENTS, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE, FREELISTS,
             FREELIST_GROUPS, RELATIVE_FNO, BUFFER_POOL)
as
select owner, segment_name, partition_name, segment_type, tablespace_name,
       header_file, header_block,
       dbms_space_admin.segment_number_blocks(tablespace_id, relative_fno,
       header_block, segment_type_id, buffer_pool_id, segment_flags,
       segment_objd, blocks)*blocksize,
       dbms_space_admin.segment_number_blocks(tablespace_id, relative_fno,
       header_block, segment_type_id, buffer_pool_id, segment_flags,
       segment_objd, blocks),
       dbms_space_admin.segment_number_extents(tablespace_id, relative_fno,
       header_block, segment_type_id, buffer_pool_id, segment_flags,
       segment_objd, extents),
       initial_extent, next_extent, min_extents, max_extents, pct_increase,
       freelists, freelist_groups, relative_fno,
       decode(buffer_pool_id, 1, 'KEEP', 2, 'RECYCLE', 'DEFAULT')
from sys_dba_segs
/

comment on table DBA_SEGMENTS_OLD is 'Storage allocated for all database segments'
/

comment on column DBA_SEGMENTS_OLD.OWNER is 'Username of the segment owner'
/

comment on column DBA_SEGMENTS_OLD.SEGMENT_NAME is 'Name, if any, of the segment'
/

comment on column DBA_SEGMENTS_OLD.PARTITION_NAME is 'Partition/Subpartition Name, if any, of the segment'
/

comment on column DBA_SEGMENTS_OLD.SEGMENT_TYPE is 'Type of segment:  "TABLE", "CLUSTER", "INDEX", "ROLLBACK",
"DEFERRED ROLLBACK", "TEMPORARY","SPACE HEADER", "TYPE2 UNDO"
 or "CACHE"'
/

comment on column DBA_SEGMENTS_OLD.TABLESPACE_NAME is 'Name of the tablespace containing the segment'
/

comment on column DBA_SEGMENTS_OLD.HEADER_FILE is 'ID of the file containing the segment header'
/

comment on column DBA_SEGMENTS_OLD.HEADER_BLOCK is 'ID of the block containing the segment header'
/

comment on column DBA_SEGMENTS_OLD.BYTES is 'Size, in bytes, of the segment'
/

comment on column DBA_SEGMENTS_OLD.BLOCKS is 'Size, in Oracle blocks, of the segment'
/

comment on column DBA_SEGMENTS_OLD.EXTENTS is 'Number of extents allocated to the segment'
/

comment on column DBA_SEGMENTS_OLD.INITIAL_EXTENT is 'Size, in bytes, of the initial extent of the segment'
/

comment on column DBA_SEGMENTS_OLD.NEXT_EXTENT is 'Size, in bytes, of the next extent to be allocated to the segment'
/

comment on column DBA_SEGMENTS_OLD.MIN_EXTENTS is 'Minimum number of extents allowed in the segment'
/

comment on column DBA_SEGMENTS_OLD.MAX_EXTENTS is 'Maximum number of extents allowed in the segment'
/

comment on column DBA_SEGMENTS_OLD.PCT_INCREASE is 'Percent by which to increase the size of the next extent to be allocated'
/

comment on column DBA_SEGMENTS_OLD.FREELISTS is 'Number of process freelists allocated in this segment'
/

comment on column DBA_SEGMENTS_OLD.FREELIST_GROUPS is 'Number of freelist groups allocated in this segment'
/

comment on column DBA_SEGMENTS_OLD.RELATIVE_FNO is 'Relative number of the file containing the segment header'
/

comment on column DBA_SEGMENTS_OLD.BUFFER_POOL is 'The default buffer pool to be used for segments blocks'
/

