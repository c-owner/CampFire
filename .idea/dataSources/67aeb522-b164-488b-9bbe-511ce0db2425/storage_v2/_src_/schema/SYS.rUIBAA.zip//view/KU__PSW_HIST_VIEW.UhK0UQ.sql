create view KU$_PSW_HIST_VIEW (VERS_MAJOR, VERS_MINOR, USER_ID, NAME, HIST_LIST) as
select '1','0', u.user#, u.name,
         cast(multiset (select * from  ku$_psw_hist_list_view p
                where p.user_id = u.user# ) as  ku$_psw_hist_list_t
         )
  from sys.user$ u
  where exists (select 1 from sys.user_history$ h where h.user# = u.user#)
/

