create view "_DBA_APPLY_CONSTRAINT_COLUMNS"
            (DEPENDENCY_NAME, OBJECT_OWNER, OBJECT_NAME, COLUMN_NAME, COLUMN_POSITION) as
select constraint_name dependency_name, owner object_owner, name object_name,
       cname column_name, cpos column_position
  from sys.apply$_constraint_columns
/

comment on column "_DBA_APPLY_CONSTRAINT_COLUMNS".DEPENDENCY_NAME is 'Dependency name'
/

comment on column "_DBA_APPLY_CONSTRAINT_COLUMNS".OBJECT_OWNER is 'Schema of owning object'
/

comment on column "_DBA_APPLY_CONSTRAINT_COLUMNS".OBJECT_NAME is 'Owning object'
/

comment on column "_DBA_APPLY_CONSTRAINT_COLUMNS".COLUMN_NAME is 'Dependency column name'
/

comment on column "_DBA_APPLY_CONSTRAINT_COLUMNS".COLUMN_POSITION is 'Dependency column position'
/

