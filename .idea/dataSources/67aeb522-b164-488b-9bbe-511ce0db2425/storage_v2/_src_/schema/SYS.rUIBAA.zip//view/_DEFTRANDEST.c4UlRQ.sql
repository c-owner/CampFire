create view "_DEFTRANDEST" (DEFERRED_TRAN_ID, DELIVERY_ORDER, DBLINK, CATCHUP) as
select C.enq_tid deferred_tran_id, C.cscn delivery_order, D.dblink,
         D.catchup
    from system.def$_aqcall C, system.def$_destination D
    where C.cscn IS NOT NULL
      AND C.cscn >= D.last_delivered
      AND (C.cscn > D.last_delivered
          OR
          (C.cscn = D.last_delivered
           AND (C.enq_tid > D.last_enq_tid)))
      and (( C.recipient_key = 0
            AND EXISTS (
              select /*+ index(CD def$_calldest_primary) */ NULL
                from system.def$_calldest CD
                where  CD.enq_tid=C.enq_tid
                  AND  CD.dblink = D.dblink
                  AND  CD.catchup = D.catchup ))
          OR ( C.recipient_key > 0
            AND ( (EXISTS (
                     SELECT NULL
                       FROM system.repcat$_repprop p
                         WHERE D.dblink = P.dblink
                           AND D.catchup = P.extension_id
                           AND P.how = 1
                           AND P.recipient_key = C.recipient_key
                           AND ((P.delivery_order is NULL)
                              OR (P.delivery_order < C.cscn))))
               OR (EXISTS (
                     SELECT NULL
                       from system.def$_aqcall C2, system.repcat$_repprop P
                       WHERE C2.enq_tid=C.enq_tid
                         AND C2.cscn IS NULL
                         AND D.dblink = P.dblink
                         AND D.catchup = P.extension_id
                         AND P.how = 1
                         AND P.recipient_key = C2.recipient_key
                         AND ((P.delivery_order is NULL) OR
                              (P.delivery_order < C.cscn)))))))
/

