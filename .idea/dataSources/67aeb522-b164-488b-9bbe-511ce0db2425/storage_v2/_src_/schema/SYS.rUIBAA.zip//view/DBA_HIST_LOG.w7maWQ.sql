create view DBA_HIST_LOG
            (SNAP_ID, DBID, INSTANCE_NUMBER, GROUP#, THREAD#, SEQUENCE#, BYTES, MEMBERS, ARCHIVED, STATUS,
             FIRST_CHANGE#, FIRST_TIME)
as
select log.snap_id, log.dbid, log.instance_number,
       group#, thread#, sequence#, bytes, members,
       archived, log.status, first_change#, first_time
  from wrm$_snapshot sn, WRH$_LOG log
  where     sn.snap_id         = log.snap_id
        and sn.dbid            = log.dbid
        and sn.instance_number = log.instance_number
        and sn.status          = 0
/

comment on table DBA_HIST_LOG is 'Log Historical Statistics Information'
/

