create view USER_DBFS_HS (STORENAME) as
SELECT storeName FROM DBA_DBFS_HS WHERE storeOwner = sys_context('USERENV', 'SESSION_USER')
/

