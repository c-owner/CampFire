create view KU$_PROCPLSQL_VIEW (OBJ_NUM, PROCEDURE_NUM, ENTRYPOINT_NUM) as
select
  obj#,
  procedure#,
  entrypoint#
  from procedureplsql$
/

