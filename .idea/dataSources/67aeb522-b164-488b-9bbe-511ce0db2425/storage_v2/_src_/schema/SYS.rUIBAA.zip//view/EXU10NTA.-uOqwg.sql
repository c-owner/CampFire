create view EXU10NTA (CLIENT, PROXY, FLAGS, ROLE_CLAUSE, AUTH) as
SELECT  u$.name, up$.name, pd$.flags,
                DECODE(pd$.flags,
                       2, 'WITH NO ROLES',
                       4, 'WITH ROLE',
                       8, 'WITH ROLE ALL EXCEPT', ' '),
                DECODE(pd$.credential_type#,
                       5, 'AUTHENTICATION REQUIRED', ' ')
        FROM    sys.user$ u$, sys.user$ up$, sys.proxy_info$ pd$
        WHERE   pd$.client# = u$.user# AND
                pd$.proxy# = up$.user#
/

