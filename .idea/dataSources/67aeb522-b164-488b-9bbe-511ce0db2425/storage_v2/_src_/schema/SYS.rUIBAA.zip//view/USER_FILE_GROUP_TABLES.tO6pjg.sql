create view USER_FILE_GROUP_TABLES (FILE_GROUP_NAME, VERSION_NAME, VERSION, OWNER, TABLE_NAME, TABLESPACE_NAME, SCN) as
select g.file_group_name, v.version_name, v.version_id,
       ti.schema_name, ti.table_name, ti.tablespace_name, ti.scn
from "_USER_FILE_GROUPS" g, sys.fgr$_table_info ti,
     sys.fgr$_file_group_versions v
where ti.version_guid = v.version_guid and v.file_group_id = g.file_group_id
/

comment on table USER_FILE_GROUP_TABLES is 'Details about the tables in the file group repository'
/

comment on column USER_FILE_GROUP_TABLES.FILE_GROUP_NAME is 'Name of the file group'
/

comment on column USER_FILE_GROUP_TABLES.VERSION_NAME is 'Name of the version'
/

comment on column USER_FILE_GROUP_TABLES.VERSION is 'Internal version number'
/

comment on column USER_FILE_GROUP_TABLES.OWNER is 'Schema table belongs to'
/

comment on column USER_FILE_GROUP_TABLES.TABLE_NAME is 'Name of the table'
/

comment on column USER_FILE_GROUP_TABLES.TABLESPACE_NAME is 'Name of the tablespace containing the table'
/

comment on column USER_FILE_GROUP_TABLES.SCN is 'SCN table was exported at'
/

