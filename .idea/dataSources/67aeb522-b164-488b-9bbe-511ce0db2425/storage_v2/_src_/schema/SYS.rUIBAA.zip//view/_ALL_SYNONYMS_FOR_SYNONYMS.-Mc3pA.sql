create view "_ALL_SYNONYMS_FOR_SYNONYMS"
            (SYN_ID, SYN_OWNER, SYN_NAME, BASE_SYN_ID, BASE_SYN_OWNER, BASE_SYN_NAME, SYN_NODE) as
select s.obj#, u.name, o.name, bo.obj#, s.owner, s.name, s.node
from sys.syn$ s, sys."_CURRENT_EDITION_OBJ" o, sys.user$ u,
     sys."_CURRENT_EDITION_OBJ" bo, sys.user$ bu
where s.obj# = o.obj#           /* get the obj$ entry for the synonym */
  and o.owner# = u.user#        /* get the owner name for the synonym */
  and s.owner = bu.name         /* get the owner id for the base object */
  and bu.user# = bo.owner#      /* get the obj$ entry for the base object */
  and s.name = bo.name          /* get the obj$ entry for the base object */
  and bo.type# = 5              /* restrict to synonyms for synonyms */
/

