create view V_$LISTENER_NETWORK (NETWORK, TYPE, VALUE) as
select "NETWORK","TYPE","VALUE" from v$listener_network
/

