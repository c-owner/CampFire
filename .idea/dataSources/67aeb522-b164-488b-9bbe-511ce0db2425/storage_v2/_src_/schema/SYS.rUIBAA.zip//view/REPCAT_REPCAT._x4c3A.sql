create view REPCAT_REPCAT (SNAME, MASTER, STATUS, SCHEMA_COMMENT, GNAME, FNAME, RPC_PROCESSING_DISABLED, GOWNER) as
SELECT r.sname, r.master,
         DECODE (r.status, 0,    'NORMAL',
                           1,    'QUIESCING',
                           2,    'QUIESCED',
                           NULL, 'NORMAL',
                                 'UNDEFINED'),
         r.schema_comment, r.sname, f.fname,
         DECODE(utl_raw.bit_and(utl_raw.substr(r.flag, 1, 1), '01'),
                '00', 'N', 'Y'),
         r.gowner
  FROM system.repcat$_repcat r, system.repcat$_flavors f
  WHERE r.sname     = f.gname (+)
    AND r.flavor_id = f.flavor_id (+)
    AND r.gowner    = f.gowner (+)
/

comment on table REPCAT_REPCAT is 'Information about all replicated object groups'
/

comment on column REPCAT_REPCAT.SNAME is 'OBSOLETE COLUMN: Name of the replicated schema'
/

comment on column REPCAT_REPCAT.MASTER is 'Is the site a master site for the replicated object group'
/

comment on column REPCAT_REPCAT.STATUS is 'If the site is a master, the master''s status'
/

comment on column REPCAT_REPCAT.SCHEMA_COMMENT is 'Description of the replicated object group'
/

comment on column REPCAT_REPCAT.GNAME is 'Name of the replicated object group'
/

comment on column REPCAT_REPCAT.FNAME is 'Flavor name'
/

comment on column REPCAT_REPCAT.RPC_PROCESSING_DISABLED is 'Whether this site disables processing of replication RPC'
/

comment on column REPCAT_REPCAT.GOWNER is 'Owner of the replicated object group'
/

