create view DBA_HIST_IOSTAT_DETAIL
            (SNAP_ID, DBID, INSTANCE_NUMBER, FUNCTION_ID, FUNCTION_NAME, FILETYPE_ID, FILETYPE_NAME,
             SMALL_READ_MEGABYTES, SMALL_WRITE_MEGABYTES, LARGE_READ_MEGABYTES, LARGE_WRITE_MEGABYTES, SMALL_READ_REQS,
             SMALL_WRITE_REQS, LARGE_READ_REQS, LARGE_WRITE_REQS, NUMBER_OF_WAITS, WAIT_TIME)
as
select io.snap_id, io.dbid, io.instance_number,
       io.function_id, nmfn.function_name,
       io.filetype_id, nmft.filetype_name,
       io.small_read_megabytes, io.small_write_megabytes,
       io.large_read_megabytes, io.large_write_megabytes,
       io.small_read_reqs, io.small_write_reqs,
       io.large_read_reqs, io.large_write_reqs,
       io.number_of_waits, io.wait_time
  from  wrm$_snapshot sn,
        WRH$_IOSTAT_DETAIL io,
        WRH$_IOSTAT_FUNCTION_NAME nmfn, WRH$_IOSTAT_FILETYPE_NAME nmft
  where     sn.snap_id         = io.snap_id
        and sn.dbid            = io.dbid
        and sn.instance_number = io.instance_number
        and sn.status          = 0
        and io.function_id     = nmfn.function_id
        and io.dbid            = nmfn.dbid
        and io.filetype_id     = nmft.filetype_id
        and io.dbid            = nmft.dbid
/

comment on table DBA_HIST_IOSTAT_DETAIL is 'Historical I/O statistics by function and filetype'
/

