create view V_$SGA (NAME, VALUE) as
select "NAME","VALUE" from v$sga
/

