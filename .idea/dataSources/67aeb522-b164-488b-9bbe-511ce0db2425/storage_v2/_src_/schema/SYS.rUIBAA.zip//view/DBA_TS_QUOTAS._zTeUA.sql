create view DBA_TS_QUOTAS (TABLESPACE_NAME, USERNAME, BYTES, MAX_BYTES, BLOCKS, MAX_BLOCKS, DROPPED) as
select ts.name, u.name, spc.blocks * ts.blocksize,
       decode(spc.maxblocks, -1, -1, spc.maxblocks * ts.blocksize),
       spc.blocks, spc.maxblocks, decode(ts.online$, 3, 'YES', 'NO')
from sys.ts$ ts, sys.tbs_space_usage spc, sys.user$ u
where spc.tsn  = ts.ts#
  and spc.user# = u.user#
  and spc.maxblocks != 0
/

comment on table DBA_TS_QUOTAS is 'Tablespace quotas for all users'
/

comment on column DBA_TS_QUOTAS.TABLESPACE_NAME is 'Tablespace name'
/

comment on column DBA_TS_QUOTAS.USERNAME is 'User with resource rights on the tablespace'
/

comment on column DBA_TS_QUOTAS.BYTES is 'Number of bytes charged to the user'
/

comment on column DBA_TS_QUOTAS.MAX_BYTES is 'User''s quota in bytes.  NULL if no limit'
/

comment on column DBA_TS_QUOTAS.BLOCKS is 'Number of ORACLE blocks charged to the user'
/

comment on column DBA_TS_QUOTAS.MAX_BLOCKS is 'User''s quota in ORACLE blocks.  NULL if no limit'
/

comment on column DBA_TS_QUOTAS.DROPPED is 'Whether the tablespace has been dropped'
/

