create view "_DBA_STREAMS_NEWLY_SUPTED_11_1" (OWNER, TABLE_NAME, REASON, COMPATIBLE, STR_COMPAT) as
select owner, table_name, reason, '11.1', 111
    from "_DBA_STREAMS_UNSUPPORTED_10_2" o
    where not exists
      (select 1 from "_DBA_STREAMS_UNSUPPORTED_11_1" i
         where i.owner = o.owner
           and i.table_name = o.table_name)
/

