create view DBA_SEGMENTS
            (OWNER, SEGMENT_NAME, PARTITION_NAME, SEGMENT_TYPE, SEGMENT_SUBTYPE, TABLESPACE_NAME, HEADER_FILE,
             HEADER_BLOCK, BYTES, BLOCKS, EXTENTS, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, MAX_SIZE,
             RETENTION, MINRETENTION, PCT_INCREASE, FREELISTS, FREELIST_GROUPS, RELATIVE_FNO, BUFFER_POOL, FLASH_CACHE,
             CELL_FLASH_CACHE)
as
select owner, segment_name, partition_name, segment_type,
       segment_subtype, tablespace_name,
       header_file, header_block,
       decode(bitand(segment_flags, 131072), 131072, blocks,
           (decode(bitand(segment_flags,1),1,
            dbms_space_admin.segment_number_blocks(tablespace_id, relative_fno,
            header_block, segment_type_id, buffer_pool_id, segment_flags,
            segment_objd, blocks), blocks)))*blocksize,
       decode(bitand(segment_flags, 131072), 131072, blocks,
           (decode(bitand(segment_flags,1),1,
            dbms_space_admin.segment_number_blocks(tablespace_id, relative_fno,
            header_block, segment_type_id, buffer_pool_id, segment_flags,
            segment_objd, blocks), blocks))),
       decode(bitand(segment_flags, 131072), 131072, extents,
           (decode(bitand(segment_flags,1),1,
           dbms_space_admin.segment_number_extents(tablespace_id, relative_fno,
           header_block, segment_type_id, buffer_pool_id, segment_flags,
           segment_objd, extents) , extents))),
       initial_extent, next_extent, min_extents, max_extents, max_size,
       retention, minretention,
       pct_increase, freelists, freelist_groups, relative_fno,
       decode(buffer_pool_id, 1, 'KEEP', 2, 'RECYCLE', 'DEFAULT'),
       decode(flash_cache, 1, 'KEEP', 2, 'NONE', 'DEFAULT'),
       decode(cell_flash_cache, 1, 'KEEP', 2, 'NONE', 'DEFAULT')
from sys_dba_segs
/

comment on table DBA_SEGMENTS is 'Storage allocated for all database segments'
/

comment on column DBA_SEGMENTS.OWNER is 'Username of the segment owner'
/

comment on column DBA_SEGMENTS.SEGMENT_NAME is 'Name, if any, of the segment'
/

comment on column DBA_SEGMENTS.PARTITION_NAME is 'Partition/Subpartition Name, if any, of the segment'
/

comment on column DBA_SEGMENTS.SEGMENT_TYPE is 'Type of segment:  "TABLE", "CLUSTER", "INDEX", "ROLLBACK",
"DEFERRED ROLLBACK", "TEMPORARY","SPACE HEADER", "TYPE2 UNDO"
 or "CACHE"'
/

comment on column DBA_SEGMENTS.SEGMENT_SUBTYPE is 'SubType of Lob segment:  "SECUREFILE", "ASSM", "MSSM", NULL'
/

comment on column DBA_SEGMENTS.TABLESPACE_NAME is 'Name of the tablespace containing the segment'
/

comment on column DBA_SEGMENTS.HEADER_FILE is 'ID of the file containing the segment header'
/

comment on column DBA_SEGMENTS.HEADER_BLOCK is 'ID of the block containing the segment header'
/

comment on column DBA_SEGMENTS.BYTES is 'Size, in bytes, of the segment'
/

comment on column DBA_SEGMENTS.BLOCKS is 'Size, in Oracle blocks, of the segment'
/

comment on column DBA_SEGMENTS.EXTENTS is 'Number of extents allocated to the segment'
/

comment on column DBA_SEGMENTS.INITIAL_EXTENT is 'Size, in bytes, of the initial extent of the segment'
/

comment on column DBA_SEGMENTS.NEXT_EXTENT is 'Size, in bytes, of the next extent to be allocated to the segment'
/

comment on column DBA_SEGMENTS.MIN_EXTENTS is 'Minimum number of extents allowed in the segment'
/

comment on column DBA_SEGMENTS.MAX_EXTENTS is 'Maximum number of extents allowed in the segment'
/

comment on column DBA_SEGMENTS.MAX_SIZE is 'Maximum number of blocks allowed in the segment'
/

comment on column DBA_SEGMENTS.RETENTION is 'Retention option for SECUREFILE segment'
/

comment on column DBA_SEGMENTS.MINRETENTION is 'Minimum Retention Duration for SECUREFILE segment'
/

comment on column DBA_SEGMENTS.PCT_INCREASE is 'Percent by which to increase the size of the next extent to be allocated'
/

comment on column DBA_SEGMENTS.FREELISTS is 'Number of process freelists allocated in this segment'
/

comment on column DBA_SEGMENTS.FREELIST_GROUPS is 'Number of freelist groups allocated in this segment'
/

comment on column DBA_SEGMENTS.RELATIVE_FNO is 'Relative number of the file containing the segment header'
/

comment on column DBA_SEGMENTS.BUFFER_POOL is 'The default buffer pool to be used for segments blocks'
/

