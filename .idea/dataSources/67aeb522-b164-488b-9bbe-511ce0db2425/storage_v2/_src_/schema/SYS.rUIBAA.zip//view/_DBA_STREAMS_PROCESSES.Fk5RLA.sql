create view "_DBA_STREAMS_PROCESSES" (STREAMS_TYPE, STREAMS_NAME, RULE_SET_OWNER, RULE_SET_NAME, RULE_SET_TYPE) as
select decode(bitand(c.flags, 512), 512, 5, 1) streams_type,
       c.capture_name streams_name,
       c.ruleset_owner, c.ruleset_name, 'POSITIVE'
  from streams$_capture_process c
union all
select 1 streams_type, c.capture_name streams_name,
       c.negative_ruleset_owner, c.negative_ruleset_name, 'NEGATIVE'
  from streams$_capture_process c
  where  bitand(c.flags, 512) != 512
union all
select 2 streams_type, p.propagation_name streams_name,
       p.ruleset_schema, p.ruleset, 'POSITIVE'
  from streams$_propagation_process p
union all
select 2 streams_type, p.propagation_name streams_name,
       p.negative_ruleset_schema, p.negative_ruleset, 'NEGATIVE'
  from streams$_propagation_process p
union all
select 3 streams_type, a.apply_name streams_name,
       a.ruleset_owner, a.ruleset_name, 'POSITIVE'
  from streams$_apply_process a
union all
select 3 streams_type, a.apply_name streams_name,
       a.negative_ruleset_owner, a.negative_ruleset_name, 'NEGATIVE'
  from streams$_apply_process a
union all
select 4 streams_type, d.streams_name,
       d.rset_owner, d.rset_name, 'POSITIVE'
  from streams$_message_consumers d
union all
select 4 streams_type, d.streams_name,
       d.neg_rset_owner, d.neg_rset_name, 'NEGATIVE'
  from streams$_message_consumers d
/

