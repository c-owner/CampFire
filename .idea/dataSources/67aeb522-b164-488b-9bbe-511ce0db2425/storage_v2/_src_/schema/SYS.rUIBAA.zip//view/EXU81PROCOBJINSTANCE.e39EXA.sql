create view EXU81PROCOBJINSTANCE
            (NAME, OBJID, OWNER, OWNERID, TYPE#, CLASS, PREPOST, LEVEL#, PACKAGE, PKG_SCHEMA, PAR_NAME, PAR_OBJID,
             PAR_PROPERTY) as
SELECT  o.name, o.objid, o.owner, o.ownerid, o.type#, o.class,
                o.prepost, o.level#, o.package, o.pkg_schema, op.name,
                d.p_obj#, t.property
        FROM    sys.exu81procobj o, sys.expdepobj$ d, sys.exu81obj op,
                sys.tab$ t
        WHERE   o.class = 3 AND
                d.d_obj# = o.objid AND
                d.p_obj# = op.obj# AND
                d.p_obj# = t.obj#
/

