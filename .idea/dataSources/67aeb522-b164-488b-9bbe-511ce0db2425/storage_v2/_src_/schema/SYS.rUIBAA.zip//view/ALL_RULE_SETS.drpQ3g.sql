create view ALL_RULE_SETS
            (RULE_SET_OWNER, RULE_SET_NAME, RULE_SET_EVAL_CONTEXT_OWNER, RULE_SET_EVAL_CONTEXT_NAME,
             RULE_SET_COMMENT) as
SELECT /*+ all_rows */
       u.name, o.name, bu.name, bo.name, r.rs_comment
FROM   rule_set$ r, obj$ o, user$ u, obj$ bo, user$ bu
WHERE  r.obj# = o.obj# and
       (o.owner# in (USERENV('SCHEMAID'), 1 /* PUBLIC */) or
        o.obj# in (select oa.obj# from sys.objauth$ oa
                   where grantee# in (select kzsrorol from x$kzsro)) or
        exists (select null from v$enabledprivs where priv_number in (
                 -251, /* create any rule set */
                 -252, /* alter any rule set */
                 -253, /* drop any rule set */
                 -254  /* execute any rule set */))) and
       u.user# = o.owner# and
       r.ectx# = bo.obj#(+) and bo.owner# = bu.user#(+)
/

comment on table ALL_RULE_SETS is 'Rule sets seen by the user'
/

comment on column ALL_RULE_SETS.RULE_SET_OWNER is 'Owner of the rule set'
/

comment on column ALL_RULE_SETS.RULE_SET_NAME is 'Name of the rule set'
/

comment on column ALL_RULE_SETS.RULE_SET_EVAL_CONTEXT_OWNER is 'The evaluation context owner name associated with the rule set, if any'
/

comment on column ALL_RULE_SETS.RULE_SET_EVAL_CONTEXT_NAME is 'The evaluation context name associated with the rule set, if any'
/

comment on column ALL_RULE_SETS.RULE_SET_COMMENT is 'user description of the rule set'
/

