create view DBA_REDEFINITION_ERRORS
            (OBJECT_TYPE, OBJECT_OWNER, OBJECT_NAME, BASE_TABLE_OWNER, BASE_TABLE_NAME, DDL_TXT, EDITION_NAME) as
select decode(obj_type, 1, 'TABLE',
                        2, 'INDEX',
                        3, 'CONSTRAINT',
                        4, 'TRIGGER',
                        6, 'NESTED TABLE',
                        7, 'PARTITION',
                        10, 'MV LOG',
                        'UNKNOWN'),
       decode(ou.type#, 2, ou.ext_username, ou.name), obj_name,
       bt_owner, bt_name, ddl_txt,
       decode(ou.type#, 2,
              (select name from sys.obj$ o where ou.spare2 = o.obj#),
              decode(obj_type, 4, 'ORA$BASE', NULL))
from sys.redef_dep_error$ e, sys.user$ ou
where e.obj_owner = ou.name
/

comment on column DBA_REDEFINITION_ERRORS.OBJECT_TYPE is 'Type of the redefinition object'
/

comment on column DBA_REDEFINITION_ERRORS.OBJECT_OWNER is 'Owner of the redefinition object'
/

comment on column DBA_REDEFINITION_ERRORS.OBJECT_NAME is 'Name of the redefinition object'
/

comment on column DBA_REDEFINITION_ERRORS.BASE_TABLE_OWNER is 'Owner of the base table of the redefinition object'
/

comment on column DBA_REDEFINITION_ERRORS.BASE_TABLE_NAME is 'Name of the base table of the redefinition object'
/

comment on column DBA_REDEFINITION_ERRORS.DDL_TXT is 'DDL used to create the corresponding interim dependent object'
/

comment on column DBA_REDEFINITION_ERRORS.EDITION_NAME is 'Name of the edition that the redefinition object belongs to'
/

