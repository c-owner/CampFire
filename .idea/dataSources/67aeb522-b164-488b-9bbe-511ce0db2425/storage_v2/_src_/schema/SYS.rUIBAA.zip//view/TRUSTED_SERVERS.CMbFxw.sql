create view TRUSTED_SERVERS (TRUST, NAME) as
select a.trust, b.dbname from sys.trusted_list$ b,
(select decode (dbname, '+*','Untrusted', '-*', 'Trusted') trust
from sys.trusted_list$ where dbname like '%*') a
where b.dbname not like '%*'
union
select decode (dbname, '-*', 'Untrusted', '+*', 'Trusted') trust, 'All'
from sys.trusted_list$
where dbname like '%*'
/

comment on table TRUSTED_SERVERS is 'Trustedness of Servers'
/

comment on column TRUSTED_SERVERS.TRUST is 'Trustedness of the server listed. Unlisted servers have opposite trustedness.'
/

comment on column TRUSTED_SERVERS.NAME is 'Server name'
/

