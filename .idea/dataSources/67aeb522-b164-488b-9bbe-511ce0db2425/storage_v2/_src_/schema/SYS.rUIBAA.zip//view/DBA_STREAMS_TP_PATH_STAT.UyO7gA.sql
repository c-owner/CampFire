create view DBA_STREAMS_TP_PATH_STAT
            (PATH_ID, STATISTIC_TIME, STATISTIC_NAME, STATISTIC_VALUE, STATISTIC_UNIT, ADVISOR_RUN_ID,
             ADVISOR_RUN_TIME) as
SELECT PATH_ID,
       STATISTIC_TIME,
       STATISTIC_NAME,
       STATISTIC_VALUE,
       STATISTIC_UNIT,
       ADVISOR_RUN_ID,
       ADVISOR_RUN_TIME
FROM streams$_path_stat_out
/

comment on table DBA_STREAMS_TP_PATH_STAT is 'DBA Streams Path Statistics'
/

comment on column DBA_STREAMS_TP_PATH_STAT.PATH_ID is 'ID of the Streams Path'
/

comment on column DBA_STREAMS_TP_PATH_STAT.STATISTIC_TIME is 'Time That the Statistic Was Taken'
/

comment on column DBA_STREAMS_TP_PATH_STAT.STATISTIC_NAME is 'Name of the Statistic'
/

comment on column DBA_STREAMS_TP_PATH_STAT.STATISTIC_VALUE is 'Value of the Statistic'
/

comment on column DBA_STREAMS_TP_PATH_STAT.STATISTIC_UNIT is 'Unit of the Statistic'
/

comment on column DBA_STREAMS_TP_PATH_STAT.ADVISOR_RUN_ID is '1-based Logical Number of Advisor Run'
/

comment on column DBA_STREAMS_TP_PATH_STAT.ADVISOR_RUN_TIME is 'Time That the Advisor Was Run'
/

