create view KU$_10_2_STRMSUBCOLTYPE_VIEW (OBJ_NUM, INTCOL_NUM, OWNER_NAME, NAME, TOID, VERSION, HASHCODE, TYPEID) as
select sct.obj#, sct.intcol#,
         o.owner_name, o.name,
         sct.toid,
         t.version#,
         sys.dbms_metadata.get_hashcode(o.owner_name,o.name),
         t.typeid
    from ku$_schemaobj_view o,type$ t, subcoltype$ sct
    where o.oid=sct.toid and o.oid=t.toid and
         NOT(o.name = 'SQL_PLAN_ALLSTAT_ROW_TYPE' and
             o.owner_name = 'SYS')
/

