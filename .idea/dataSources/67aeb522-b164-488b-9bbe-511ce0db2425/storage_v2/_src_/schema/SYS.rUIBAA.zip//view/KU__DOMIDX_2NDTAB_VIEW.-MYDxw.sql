create view KU$_DOMIDX_2NDTAB_VIEW (OBJ_NUM, SECOBJ_NUM, SCHEMA_OBJ) as
select s.obj#, s.secobj#, value(o)
  from sys.ku$_schemaobj_view o, sys.secobj$ s
  where o.obj_num = s.secobj#
    and o.type_num = 2
    and dbms_metadata.oktoexp_2ndary_table(s.secobj#)!= 0
/

