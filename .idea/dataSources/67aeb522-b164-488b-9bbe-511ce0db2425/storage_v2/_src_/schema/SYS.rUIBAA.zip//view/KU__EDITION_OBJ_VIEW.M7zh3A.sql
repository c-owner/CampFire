create view KU$_EDITION_OBJ_VIEW
            (OBJ#, DATAOBJ#, DEFINING_OWNER#, NAME, NAMESPACE, SUBNAME, TYPE#, CTIME, MTIME, STIME, STATUS, REMOTEOWNER,
             LINKNAME, FLAGS, OID$, SPARE1, SPARE2, SPARE3, SPARE4, SPARE5, SPARE6, OWNER#, DEFINING_EDITION)
as
select o."OBJ#",o."DATAOBJ#",o."OWNER#",o."NAME",o."NAMESPACE",o."SUBNAME",o."TYPE#",o."CTIME",o."MTIME",o."STIME",o."STATUS",o."REMOTEOWNER",o."LINKNAME",o."FLAGS",o."OID$",o."SPARE1",o."SPARE2",o."SPARE3",o."SPARE4",o."SPARE5",o."SPARE6",
       o.spare3,
       case when (o.type# not in (4,5,7,8,9,10,11,12,13,14,22,87) or
                  bitand(u.spare1, 16) = 0) then
         null
       when (u.type# = 2) then
        (select eo.name from obj$ eo where eo.obj# = u.spare2)
       else
        'ORA$BASE'
       end
from obj$ o, user$ u
where o.owner# = u.user#
  and (   /* non-versionable object */
          (   o.type# not in (4,5,7,8,9,10,11,12,13,14,22,87,88)
           or bitand(u.spare1, 16) = 0)
          /* versionable object visible in designated edition */
       or (    o.type# in (4,5,7,8,9,10,11,12,13,14,22,87)
           and (   (u.type# <> 2 and
                    (select distinct sys.dbms_metadata.get_edition from dual)
                        = 'ORA$BASE')
                or (u.type# = 2 and
                    u.spare2 =
                        (select distinct sys.dbms_metadata.get_edition_id from dual))
                or exists (select 1 from obj$ o2, user$ u2
                           where o2.type# = 88
                             and o2.dataobj# = o.obj#
                             and o2.owner# = u2.user#
                             and u2.type#  = 2
                             and u2.spare2 =
                        (select distinct sys.dbms_metadata.get_edition_id from dual))
               )
          )
      )
/

