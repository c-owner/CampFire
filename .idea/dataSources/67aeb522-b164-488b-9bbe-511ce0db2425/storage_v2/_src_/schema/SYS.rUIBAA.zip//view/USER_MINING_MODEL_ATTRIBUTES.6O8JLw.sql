create view USER_MINING_MODEL_ATTRIBUTES
            (MODEL_NAME, ATTRIBUTE_NAME, ATTRIBUTE_TYPE, DATA_TYPE, DATA_LENGTH, DATA_PRECISION, DATA_SCALE, USAGE_TYPE,
             TARGET) as
select o.name, a.name,
       decode(atyp, /* attribute type */
              1, 'NUMERICAL',
              2, 'CATEGORICAL',
              3, 'ORDINAL',
                 'UNDEFINED'),
       decode(dtyp, /* data type */
              1, 'VARCHAR2',
              2, 'NUMBER',
              4, 'FLOAT',
             96, 'CHAR',
            122, 'NESTED TABLE',
                 'UNDEFINED'),
       a.length,
       a.precision#,
       a.scale,
       decode(bitand(a.properties,1),1,'ACTIVE','INACTIVE'),
       decode(bitand(a.properties,2),2,'YES','NO')
from sys.modelatt$ a, sys.obj$ o
where o.obj#=a.mod#
  and o.owner#=userenv('SCHEMAID')
  and bitand(a.properties, 4) = 0
/

comment on table USER_MINING_MODEL_ATTRIBUTES is 'Description of the user''s own model attributes'
/

comment on column USER_MINING_MODEL_ATTRIBUTES.MODEL_NAME is 'Name of the model to which the attribute belongs'
/

comment on column USER_MINING_MODEL_ATTRIBUTES.ATTRIBUTE_NAME is 'Name of the attribute'
/

comment on column USER_MINING_MODEL_ATTRIBUTES.ATTRIBUTE_TYPE is 'Mining type of the attribute'
/

comment on column USER_MINING_MODEL_ATTRIBUTES.DATA_TYPE is 'Data type of the attribute'
/

comment on column USER_MINING_MODEL_ATTRIBUTES.DATA_LENGTH is 'Data length of the attribute'
/

comment on column USER_MINING_MODEL_ATTRIBUTES.DATA_PRECISION is 'Data precision of the attribute'
/

comment on column USER_MINING_MODEL_ATTRIBUTES.DATA_SCALE is 'Data scale of the attribute'
/

comment on column USER_MINING_MODEL_ATTRIBUTES.USAGE_TYPE is 'Usage type for the attribute'
/

