create view UTL_RECOMP_ALL_OBJECTS (OBJ#, OWNER, OBJNAME, TYPE#, NAMESPACE, STATUS, EDITION_NAME) as
SELECT o.obj#, u.name owner, o.name objname, o.type#, o.namespace, o.status,
          o.defining_edition edition_name
   FROM "_ACTUAL_EDITION_OBJ" o, user$ u
   WHERE     o.owner# = u.user#
         AND o.remoteowner IS NULL
         AND (   o.type# IN (1, 2, 4, 5, 7, 8, 9, 11, 12, 14,
                             22, 24, 29, 32, 33, 42, 43, 46, 59, 62)
              OR (o.type# = 13 AND o.subname IS NULL AND
                  NOT REGEXP_LIKE(o.name, 'SYS_PLSQL_[0-9]+_[0-9]+_[12]')))
         AND (BITAND(o.flags, 128) = 0)
   UNION ALL
   SELECT s.obj#, a.ext_username owner, s.name objname, s.type#, s.namespace,
          s.status, e.name edition_name
   FROM  obj$ s, user$ a, obj$ e
   WHERE     s.remoteowner IS NULL
         AND s.type# = 88
         AND s.status = 5
         AND s.owner# = a.user#
         AND a.spare2 = e.obj#
/

