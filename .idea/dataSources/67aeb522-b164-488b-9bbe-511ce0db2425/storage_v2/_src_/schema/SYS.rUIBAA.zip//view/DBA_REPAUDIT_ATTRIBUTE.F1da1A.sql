create view DBA_REPAUDIT_ATTRIBUTE (ATTRIBUTE, DATA_TYPE, DATA_LENGTH, SOURCE) as
select
    attribute,
    decode(data_type_id,
           1, 'NUMBER',
           2, 'VARCHAR2',
           3, 'DATE',
           4, 'CHAR',
           5, 'RAW',
           6, 'NVARCHAR2',
           7, 'NCHAR',
           'UNDEFINED'),
    data_length,
    source
from  system.repcat$_audit_attribute
/

comment on table DBA_REPAUDIT_ATTRIBUTE is 'Information about attributes automatically maintained for replication'
/

comment on column DBA_REPAUDIT_ATTRIBUTE.ATTRIBUTE is 'Description of the attribute'
/

comment on column DBA_REPAUDIT_ATTRIBUTE.DATA_TYPE is 'Datatype of the attribute value'
/

comment on column DBA_REPAUDIT_ATTRIBUTE.DATA_LENGTH is 'Length of the attribute value in byte'
/

comment on column DBA_REPAUDIT_ATTRIBUTE.SOURCE is 'Name of the function which returns the attribute value'
/

