create view USER_REPPROP (SNAME, ONAME, TYPE, DBLINK, HOW, PROPAGATE_COMMENT) as
select r.sname, r.oname, r.type, r.dblink, r.how, r.propagate_comment
from repcat_repprop r, repcat_repobject ro, user_users u
where r.sname = u.username
  and r.sname = ro.sname
  and r.oname = ro.oname
  and r.type = ro.type
  and ro.type in ('PROCEDURE', 'PACKAGE', 'PACKAGE BODY', 'TABLE', 'SNAPSHOT')
/

comment on table USER_REPPROP is 'Propagation information about the current user''s objects'
/

comment on column USER_REPPROP.SNAME is 'Name of the user'
/

comment on column USER_REPPROP.ONAME is 'Name of the object'
/

comment on column USER_REPPROP.TYPE is 'Type of the object'
/

comment on column USER_REPPROP.DBLINK is 'Destination database for propagation'
/

comment on column USER_REPPROP.HOW is 'Propagation choice for the destination database'
/

comment on column USER_REPPROP.PROPAGATE_COMMENT is 'User description of the propagation choice'
/

