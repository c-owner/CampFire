create view DBA_STREAMS_TP_COMPONENT
            (COMPONENT_ID, COMPONENT_NAME, COMPONENT_DB, COMPONENT_TYPE, COMPONENT_CHANGED_TIME) as
SELECT COMPONENT_ID,
       nvl(COMPONENT_NAME, SPARE3) COMPONENT_NAME,
       COMPONENT_DB,
       decode(COMPONENT_TYPE,
              1, 'CAPTURE',
              2, 'PROPAGATION SENDER',
              3, 'PROPAGATION RECEIVER',
              4, 'APPLY',
              5, 'QUEUE',
              NULL) COMPONENT_TYPE,
       COMPONENT_CHANGED_TIME
FROM streams$_component
/

comment on table DBA_STREAMS_TP_COMPONENT is 'DBA Streams Component'
/

comment on column DBA_STREAMS_TP_COMPONENT.COMPONENT_ID is 'ID of the Streams Component'
/

comment on column DBA_STREAMS_TP_COMPONENT.COMPONENT_NAME is 'Name of the Streams Component'
/

comment on column DBA_STREAMS_TP_COMPONENT.COMPONENT_DB is 'Database Where the Streams Component Resides'
/

comment on column DBA_STREAMS_TP_COMPONENT.COMPONENT_TYPE is 'Type of the Streams Component'
/

comment on column DBA_STREAMS_TP_COMPONENT.COMPONENT_CHANGED_TIME is 'Time That the Component Was Last Changed by a DDL'
/

