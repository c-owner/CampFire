create view ALL_SCHEDULER_GROUPS (OWNER, GROUP_NAME, GROUP_TYPE, ENABLED, NUMBER_OF_MEMBERS, COMMENTS) as
SELECT u.name, o.name,
  decode(bitand(w.flags, 8+16), 0, 'WINDOW', 8, 'JOB', 16,
decode(bitand(w.flags, 4096+8192), 4096,'DB_DEST', 8192, 'EXTERNAL_DEST', 'UNKOWN_DEST')),
  DECODE(BITAND(w.flags,1),0,'FALSE',1,'TRUE'),
  (SELECT COUNT(*) FROM all_scheduler_group_members agm
   WHERE agm.group_name = o.name and agm.owner = u.name),
  w.comments
FROM obj$ o, user$ u, scheduler$_window_group w
WHERE o.owner# = u.user# AND o.obj# = w.obj# AND
  ( bitand(w.flags, 8+16)=0            -- window group
    or o.owner# = userenv('SCHEMAID')  -- user is owner
    or o.obj# in                       -- user has obj privs on group
         (select oa.obj#
          from sys.objauth$ oa
          where grantee# in ( select kzsrorol
                              from x$kzsro
                            )
         )
    or /* user has create any job, except for SYS group */
      (exists (select null from v$enabledprivs
              where priv_number in (-265 /* CREATE ANY JOB */)
              )
       and o.owner#!=0)
  )
/

comment on table ALL_SCHEDULER_GROUPS is 'All scheduler object groups visible to current user'
/

comment on column ALL_SCHEDULER_GROUPS.OWNER is 'Owner of the group'
/

comment on column ALL_SCHEDULER_GROUPS.GROUP_NAME is 'Name of the group'
/

comment on column ALL_SCHEDULER_GROUPS.GROUP_TYPE is 'Type of object contained in the group'
/

comment on column ALL_SCHEDULER_GROUPS.ENABLED is 'Whether the group is enabled'
/

comment on column ALL_SCHEDULER_GROUPS.NUMBER_OF_MEMBERS is 'Number of members in this group'
/

comment on column ALL_SCHEDULER_GROUPS.COMMENTS is 'An optional comment about this group'
/

