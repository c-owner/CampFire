create view DBA_SCHEDULER_DESTS (OWNER, DESTINATION_NAME, DESTINATION_TYPE, ENABLED, COMMENTS) as
SELECT u.name, o.name,
  decode(bitand(d.flags, 2+4), 2, 'EXTERNAL', 4, 'DATABASE'),
  decode(bitand(d.flags, 1), 1, 'TRUE', 'FALSE'), d.comments
FROM scheduler$_destinations d, user$ u, obj$ o
WHERE u.user# = o.owner# AND o.obj# = d.obj#
      and bitand(d.flags, 8) = 0
/

comment on table DBA_SCHEDULER_DESTS is 'All possible destination objects for jobs in the database'
/

comment on column DBA_SCHEDULER_DESTS.OWNER is 'Owner of this destination object'
/

comment on column DBA_SCHEDULER_DESTS.DESTINATION_NAME is 'Name of this destination object'
/

comment on column DBA_SCHEDULER_DESTS.DESTINATION_TYPE is 'Type of this destination object'
/

comment on column DBA_SCHEDULER_DESTS.ENABLED is 'Whether this destination object is enabled'
/

comment on column DBA_SCHEDULER_DESTS.COMMENTS is 'Optional comment'
/

