create view DBA_ADVISOR_PARAMETERS_PROJ
            (TASK_ID, PARAMETER_NAME, PARAMETER_VALUE, PARAMETER_TYPE, IS_DEFAULT, IS_OUTPUT, IS_MODIFIABLE_ANYTIME,
             IS_SYSTEM_TASK_ONLY, DESCRIPTION)
as
select a.task_id as task_id,
             a.name as parameter_name,
             a.value as parameter_value,
             decode(a.datatype, 1, 'NUMBER',
                                2, 'STRING',
                                3, 'STRINGLIST',
                                4, 'TABLE',
                                5, 'TABLELIST',
                                'UNKNOWN')
                 as parameter_type,
             decode(bitand(a.flags,2), 0, 'Y', 'N') as is_default,
             decode(bitand(a.flags,4), 0, 'N', 'Y') as is_output,
             decode(bitand(a.flags,8), 0, 'N', 'Y') as is_modifiable_anytime,
             decode(bitand(a.flags,16), 0, 'N', 'Y') as is_system_task_only,
             dbms_advisor.format_message(a.description) as description
      from wri$_adv_parameters a
/

