create view DBA_SQLSET_BINDS
            (SQLSET_NAME, SQLSET_OWNER, SQLSET_ID, SQL_ID, FORCE_MATCHING_SIGNATURE, PLAN_HASH_VALUE, POSITION, VALUE,
             CAPTURED, SQL_SEQ)
as
select d.name as sqlset_name, d.owner as sqlset_owner, s.sqlset_id,
         s.sql_id, s.force_matching_signature, p.plan_hash_value,
         b.position, b.value, p.binds_captured as captured, s.id as sql_seq
  from   WRI$_SQLSET_DEFINITIONS d, WRI$_SQLSET_STATEMENTS s,
         WRI$_SQLSET_PLANS p, WRI$_SQLSET_BINDS b
  where  d.id = s.sqlset_id and s.id = p.stmt_id AND p.stmt_id = b.stmt_id AND
         p.plan_hash_value = b.plan_hash_value
  UNION ALL
  select d.name as sqlset_name, d.owner as sqlset_owner, s.sqlset_id,
         s.sql_id, s.force_matching_signature, p.plan_hash_value,
         b.position, b.value_anydata as value, p.binds_captured as captured,
         s.id as sql_seq
  from   WRI$_SQLSET_DEFINITIONS d, WRI$_SQLSET_STATEMENTS s,
         WRI$_SQLSET_PLANS p, TABLE(dbms_sqltune.extract_binds(p.bind_data)) b
  where  d.id = s.sqlset_id AND s.id = p.stmt_id
/

