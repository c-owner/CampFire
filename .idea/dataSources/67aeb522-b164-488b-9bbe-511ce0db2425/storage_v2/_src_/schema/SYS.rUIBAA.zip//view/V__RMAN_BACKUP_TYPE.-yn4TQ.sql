create view V_$RMAN_BACKUP_TYPE (WEIGHT, INPUT_TYPE) as
select "WEIGHT","INPUT_TYPE" from v$rman_backup_type
/

