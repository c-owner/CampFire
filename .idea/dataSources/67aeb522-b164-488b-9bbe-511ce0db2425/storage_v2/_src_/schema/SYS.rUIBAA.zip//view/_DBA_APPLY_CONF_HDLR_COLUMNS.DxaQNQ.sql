create view "_DBA_APPLY_CONF_HDLR_COLUMNS" (OBJECT_NUMBER, RESOLUTION_ID, COLUMN_NAME, SPARE1) as
select
  object_number, resolution_id, column_name, spare1
from sys.apply$_conf_hdlr_columns
/

