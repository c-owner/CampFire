create view DBA_HIST_DATAFILE (DBID, FILE#, CREATION_CHANGE#, FILENAME, TS#, TSNAME, BLOCK_SIZE) as
select dbid, file#, creation_change#,
       filename, ts#, coalesce(t.tsname, d.tsname) tsname, block_size
from WRH$_DATAFILE d LEFT OUTER JOIN WRH$_TABLESPACE t USING (dbid, ts#)
/

comment on table DBA_HIST_DATAFILE is 'Names of Datafiles'
/

