create view USER_FLASHBACK_ARCHIVE_TABLES
            (TABLE_NAME, OWNER_NAME, FLASHBACK_ARCHIVE_NAME, ARCHIVE_TABLE_NAME, STATUS) as
select unique o.NAME, d.USERNAME, f.FANAME, 'SYS_FBA_HIST_'||o.obj#,
     case bitand(t.FLAGS,160)
       when 128 then 'DISABLED'
       when 32  then 'DISASSOCIATED'
       else 'ENABLED'
     end
from OBJ$ o, USER$ u, SYS_FBA_FA f, SYS_FBA_TRACKEDTABLES t,
     SYS.OBJAUTH$ oa, SYS.DBA_USERS d
where t.FA# = f.FA# and t.OBJ# = o.OBJ# and o.OWNER# = d.USER_ID and
  /* user is owner of the table or has alter privilege on the table */
  ((o.OWNER# = u.USER#) or
   (o.OBJ# = oa.OBJ# and oa.GRANTEE# = u.user# and oa.PRIVILEGE# = 0))
  and
  /* user has system privileges or flashback archive object privilege */
  ((exists (select null from v$enabledprivs where priv_number = -350)) or
   (t.FA# = (select FA# from SYS_FBA_USERS fp where fp.user# = u.USER#)))
  and
  /* show only this user's objects */
  (u.user# = userenv('SCHEMAID'))
/

comment on table USER_FLASHBACK_ARCHIVE_TABLES is 'Information about the user tables that are enabled for Flashback Archive'
/

comment on column USER_FLASHBACK_ARCHIVE_TABLES.TABLE_NAME is 'Name of the table enabled for Flashback Archive'
/

comment on column USER_FLASHBACK_ARCHIVE_TABLES.OWNER_NAME is 'Owner name of the table enabled for Flashback Archive'
/

comment on column USER_FLASHBACK_ARCHIVE_TABLES.FLASHBACK_ARCHIVE_NAME is 'Name of the flashback archive'
/

comment on column USER_FLASHBACK_ARCHIVE_TABLES.ARCHIVE_TABLE_NAME is 'Name of the archive table containing the historical data for the user table'
/

comment on column USER_FLASHBACK_ARCHIVE_TABLES.STATUS is 'Status of whether flashback archive is enabled or being disabled on the table'
/

