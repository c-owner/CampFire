create view TTS_OBJ_VIEW
            (OBJ#, DATAOBJ#, OWNER#, NAME, NAMESPACE, SUBNAME, TYPE#, CTIME, MTIME, STIME, STATUS, REMOTEOWNER,
             LINKNAME, FLAGS, OID$, SPARE1, SPARE2, SPARE3, SPARE4, SPARE5, SPARE6)
as
select obj#,
       dataobj#,
       owner#,
       name,
       namespace,
       subname,
       type#,
       ctime,
       mtime,
       stime,
       status,
       remoteowner,
       linkname,
       flags,
       oid$,
       spare1,
       spare2,
       spare3,
       spare4,
       spare5,
       spare6
from "_CURRENT_EDITION_OBJ" where bitand(flags, 128)=0
/

