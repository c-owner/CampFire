create view KU$_PKG_VIEW (VERS_MAJOR, VERS_MINOR, OBJ_NUM, TYPE_NUM, SCHEMA_OBJ, SOURCE_LINES) as
select t.vers_major, t.vers_minor, t.obj_num, t.type_num,
         t.schema_obj, t.source_lines
  from ku$_base_proc_view t
  where t.type_num = 9
/

