create view KU$_PLUGTS_TSNAME_INDEXP_VIEW
            (VERS_MAJOR, VERS_MINOR, USER_NAME, OBJ_NUM, BASE_OBJ, PACKAGE, PKG_SCHEMA, LEVEL_NUM, CLASS, PREPOST,
             TS_NAME, INCL_CONST, INCL_TRIG, INCL_GRANT, TTS_FULL_CHK, TTS_CLOSURE_CHK)
as
select '1','0',
  null, tts.obj_num, tts.partobj,
  'DBMS_PLUGTS','SYS',
  0,
  101,
  0,
  tts.ts_name,
  null, null, null, null, null
  FROM sys.ku$_ttsp_idx_tablespace_view tts
  where bitand(tts.poflags,1)=1 and
        (SYS_CONTEXT('USERENV','CURRENT_USERID')=0
                 OR EXISTS ( SELECT * FROM sys.session_roles
                    WHERE role='SELECT_CATALOG_ROLE' ))
/

