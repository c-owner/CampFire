create view DBA_STREAMS_TP_PATH_BOTTLENECK
            (PATH_ID, COMPONENT_ID, COMPONENT_NAME, COMPONENT_DB, COMPONENT_TYPE, TOP_SESSION_ID, TOP_SESSION_SERIAL#,
             ACTION_NAME, BOTTLENECK_IDENTIFIED, ADVISOR_RUN_ID, ADVISOR_RUN_TIME, ADVISOR_RUN_REASON)
as
SELECT B.PATH_ID,
       B.COMPONENT_ID,
       nvl(C.COMPONENT_NAME, C.SPARE3) COMPONENT_NAME,
       C.COMPONENT_DB,
       decode(C.COMPONENT_TYPE,
              1, 'CAPTURE',
              2, 'PROPAGATION SENDER',
              3, 'PROPAGATION RECEIVER',
              4, 'APPLY',
              5, 'QUEUE',
              NULL),
       B.TOP_SESSION_ID,
       B.TOP_SESSION_SERIAL#,
       B.ACTION_NAME,
       B.BOTTLENECK_IDENTIFIED,
       B.ADVISOR_RUN_ID,
       B.ADVISOR_RUN_TIME,
       B.ADVISOR_RUN_REASON
FROM streams$_component C,
     streams$_path_bottleneck_out B
WHERE B.COMPONENT_ID = C.COMPONENT_ID (+)
/

comment on table DBA_STREAMS_TP_PATH_BOTTLENECK is 'DBA Streams Path Bottleneck'
/

comment on column DBA_STREAMS_TP_PATH_BOTTLENECK.PATH_ID is 'ID of the Streams Path'
/

comment on column DBA_STREAMS_TP_PATH_BOTTLENECK.COMPONENT_NAME is 'Name of the Bottleneck Component'
/

comment on column DBA_STREAMS_TP_PATH_BOTTLENECK.COMPONENT_DB is 'Database Where the Bottleneck Component resides'
/

comment on column DBA_STREAMS_TP_PATH_BOTTLENECK.COMPONENT_TYPE is 'Type of the Bottleneck Component'
/

comment on column DBA_STREAMS_TP_PATH_BOTTLENECK.TOP_SESSION_ID is 'ID of the Top Session for the Bottleneck Component'
/

comment on column DBA_STREAMS_TP_PATH_BOTTLENECK.TOP_SESSION_SERIAL# is 'Serial# of the Top Session for the Bottleneck Component'
/

comment on column DBA_STREAMS_TP_PATH_BOTTLENECK.ACTION_NAME is 'Action Name for the Bottleneck Process'
/

comment on column DBA_STREAMS_TP_PATH_BOTTLENECK.BOTTLENECK_IDENTIFIED is 'Whether Bottlecneck Was Identified'
/

comment on column DBA_STREAMS_TP_PATH_BOTTLENECK.ADVISOR_RUN_ID is '1-Based Logical Number of Advisor Run'
/

comment on column DBA_STREAMS_TP_PATH_BOTTLENECK.ADVISOR_RUN_TIME is 'Time That the Advisor Was Run'
/

comment on column DBA_STREAMS_TP_PATH_BOTTLENECK.ADVISOR_RUN_REASON is 'Reasons for Bottleneck Analysis Results'
/

