create view V_$RECOVERY_FILE_STATUS (FILENUM, FILENAME, STATUS) as
select "FILENUM","FILENAME","STATUS" from v$recovery_file_status
/

