create view KU$_DUMMY_REALM_VIEW (VERS_MAJOR, VERS_MINOR, NAME) as
select '0','0',NULL
    from dual
   where 1=0      -- return 0 rows
/

