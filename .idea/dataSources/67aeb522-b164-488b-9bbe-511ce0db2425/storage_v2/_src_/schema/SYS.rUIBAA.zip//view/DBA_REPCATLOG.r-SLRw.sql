create view DBA_REPCATLOG
            (ID, SOURCE, STATUS, USERID, TIMESTAMP, ROLE, MASTER, SNAME, REQUEST, ONAME, TYPE, MESSAGE, ERRNUM,
             GNAME) as
select r.id, r.source, r.status, r.userid, r.timestamp, r.role, r.master,
  r.sname, r.request, r.oname, r.type, r.message, r.errnum, r.gname
from repcat_repcatlog r
/

comment on table DBA_REPCATLOG is 'Information about asynchronous administration requests'
/

comment on column DBA_REPCATLOG.ID is 'Identifying number of repcat log record'
/

comment on column DBA_REPCATLOG.SOURCE is 'Name of the database at which the request originated'
/

comment on column DBA_REPCATLOG.STATUS is 'Status of the request at this database'
/

comment on column DBA_REPCATLOG.USERID is 'Name of the user who submitted the request'
/

comment on column DBA_REPCATLOG.TIMESTAMP is 'When the request was submitted'
/

comment on column DBA_REPCATLOG.ROLE is 'Is this database the masterdef for the request'
/

comment on column DBA_REPCATLOG.MASTER is 'Name of the database that processes this request'
/

comment on column DBA_REPCATLOG.SNAME is 'Schema of replicated object name, if applicable'
/

comment on column DBA_REPCATLOG.REQUEST is 'Name of the requested operation'
/

comment on column DBA_REPCATLOG.ONAME is 'Replicated object name, if applicable'
/

comment on column DBA_REPCATLOG.TYPE is 'Type of replicated object, if applicable'
/

comment on column DBA_REPCATLOG.MESSAGE is 'Error message associated with processing the request'
/

comment on column DBA_REPCATLOG.ERRNUM is 'Oracle error number associated with processing the request'
/

comment on column DBA_REPCATLOG.GNAME is 'Name of the replicated object group'
/

