create view ALL_CHANGE_SOURCES
            (SOURCE_NAME, DBID, LOG_DIRECTORY, LOGFILE_PATTERN, SOURCE_DESCRIPTION, CREATED, SOURCE_TYPE,
             SOURCE_DATABASE, FIRST_SCN, PUBLISHER, CAPTURE_NAME, CAPTURE_QUEUE_NAME, CAPTURE_QUEUE_TABLE_NAME,
             SOURCE_ENABLED)
as
SELECT
   s.source_name, s.dbid, s.logfile_location, s.logfile_suffix,
   s.source_description, s.created,
   decode(bitand(s.source_type, 206),
                         2, 'AUTOLOG',
                         4, 'HOTLOG',
                         8, 'SYNCHRONOUS',
                        68, 'DISTRIBUTED HOTLOG',
                       130, 'AUTOLOG ONLINE',
                            'UNKNOWN'),
   s.source_database, s.first_scn, s.publisher,
   s.capture_name, s.capqueue_name, s.capqueue_tabname,
   s.source_enabled
  FROM sys.cdc_change_sources$ s
/

comment on table ALL_CHANGE_SOURCES is 'Change Data Capture change sources'
/

comment on column ALL_CHANGE_SOURCES.SOURCE_NAME is 'Name of the change source'
/

comment on column ALL_CHANGE_SOURCES.DBID is 'Database identifier'
/

comment on column ALL_CHANGE_SOURCES.LOG_DIRECTORY is 'Log file directory location'
/

comment on column ALL_CHANGE_SOURCES.LOGFILE_PATTERN is 'File name wildcard pattern for log files'
/

comment on column ALL_CHANGE_SOURCES.SOURCE_DESCRIPTION is 'Description of the change source'
/

comment on column ALL_CHANGE_SOURCES.CREATED is 'Creation date of the change source'
/

comment on column ALL_CHANGE_SOURCES.SOURCE_TYPE is 'Capture mode of the change source'
/

comment on column ALL_CHANGE_SOURCES.SOURCE_DATABASE is 'Global name of source database'
/

comment on column ALL_CHANGE_SOURCES.FIRST_SCN is 'SCN of a LogMiner dictionary at which capture can begin'
/

comment on column ALL_CHANGE_SOURCES.PUBLISHER is 'Publisher of the change source'
/

comment on column ALL_CHANGE_SOURCES.CAPTURE_NAME is 'Name of the Streams capture'
/

comment on column ALL_CHANGE_SOURCES.CAPTURE_QUEUE_NAME is 'Name of the Streams capture queue name'
/

comment on column ALL_CHANGE_SOURCES.CAPTURE_QUEUE_TABLE_NAME is 'Name of the Streams capture table name'
/

comment on column ALL_CHANGE_SOURCES.SOURCE_ENABLED is 'Whether change source is enabled ?'
/

