create view KU$_TLOB_COMPPART_VIEW
            (BASE_OBJNUM, COLNAME, INTCOL_NUM, SPART_POS, FLAGS, LOB_SPART_NAME, TS_NAME, TS_NUM) as
select  dspl.bo#, '"'||c.name||'"', dspl.intcol#,
             dspl.spart_position, dspl.flags, dspl.lob_spart_name,
             (select(t.name) from sys.ts$ t where t.ts# = dspl.lob_spart_ts#),
             dspl.lob_spart_ts#
     from    sys.col$ c, sys.defsubpartlob$ dspl
     where   dspl.bo# = c.obj#
         and dspl.intcol# = c.col#
/

