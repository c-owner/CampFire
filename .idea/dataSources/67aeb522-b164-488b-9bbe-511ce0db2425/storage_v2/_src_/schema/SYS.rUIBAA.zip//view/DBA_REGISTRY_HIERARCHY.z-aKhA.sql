create view DBA_REGISTRY_HIERARCHY (NAMESPACE, COMP_ID, VERSION, STATUS, MODIFIED) as
SELECT namespace, LPAD(' ',2*(LEVEL-1)) || LEVEL || ' ' || cid, version,
       SUBSTR(dbms_registry.status_name(status),1,11),
       TO_CHAR(modified,'DD-MON-YYYY HH24:MI:SS')
FROM registry$
START WITH pid IS NULL
CONNECT BY PRIOR cid = pid and PRIOR namespace = namespace
/

