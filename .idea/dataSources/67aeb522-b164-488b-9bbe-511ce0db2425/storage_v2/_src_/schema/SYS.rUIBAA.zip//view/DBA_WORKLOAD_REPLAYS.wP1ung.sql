create view DBA_WORKLOAD_REPLAYS
            (ID, NAME, DBID, DBNAME, DBVERSION, PARALLEL, DIRECTORY, CAPTURE_ID, STATUS, PREPARE_TIME, START_TIME,
             END_TIME, DURATION_SECS, NUM_CLIENTS, NUM_CLIENTS_DONE, FILTER_SET_NAME, DEFAULT_ACTION, SYNCHRONIZATION,
             CONNECT_TIME_SCALE, THINK_TIME_SCALE, THINK_TIME_AUTO_CORRECT, SCALE_UP_MULTIPLIER, USER_CALLS, DBTIME,
             NETWORK_TIME, THINK_TIME, PAUSE_TIME, ELAPSED_TIME_DIFF, AWR_DBID, AWR_BEGIN_SNAP, AWR_END_SNAP,
             AWR_EXPORTED, ERROR_CODE, ERROR_MESSAGE, DIR_PATH, REPLAY_DIR_NUMBER, SQLSET_OWNER, SQLSET_NAME)
as
select
 r.id, r.name
 , r.dbid, r.dbname, r.dbversion
 , (case when rs.parallel > 0 then 'YES' else 'NO' end)
 , r.directory
 , r.capture_id
 , r.status
 , r.prepare_time, r.start_time, r.end_time
 , round((r.end_time - r.start_time) * 86400)
 , r.num_clients
 , r.num_clients_done
 , r.filter_set_name
 , r.default_action
 , decode(r.synchronization, 1, 'SCN', 2, 'OBJECT_ID', 'FALSE')
 , r.connect_time_scale
 , r.think_time_scale
 , decode(r.think_time_auto_correct, 1, 'TRUE', 'FALSE')
 , r.scale_up_multiplier
 , rs.user_calls, rs.dbtime, rs.network_time, rs.think_time, rs.time_paused
 , (rs.time_gain - rs.time_loss)
 , r.awr_dbid, r.awr_begin_snap, r.awr_end_snap
 , decode(r.awr_exported, 1, 'YES', 0, 'NO', 'NOT POSSIBLE')
 , r.error_code, r.error_msg
 , r.dir_path
 , r.replay_dir_number
 , r.sqlset_owner
 , r.sqlset_name
from
 wrr$_replays r
 , (select id,
           sum(decode(parallel,'YES',1,0)) as parallel,
           sum(user_calls) as user_calls,
           sum(dbtime) as dbtime,
           sum(network_time) as network_time,
           sum(think_time) as think_time,
           sum(time_gain) as time_gain,
           sum(time_loss) as time_loss,
           sum(time_paused) as time_paused
    from   wrr$_replay_stats
    group by id) rs
where r.id = rs.id(+)
and   nvl(r.replay_type, 'DB') = 'DB'
/

