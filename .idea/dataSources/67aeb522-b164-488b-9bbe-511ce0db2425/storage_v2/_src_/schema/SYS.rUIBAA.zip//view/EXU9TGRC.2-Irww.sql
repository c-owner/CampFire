create view EXU9TGRC
            (OWNERID, OWNER, BASEOBJECT, DEFINITION, WHENCLAUSE, ACTION, ENABLED, TPROPERTY, NAME, BASENAME, BASETYPE,
             PROPERTY, BTOWNER, BTOWNERID, ACTIONSIZE)
as
SELECT  "OWNERID","OWNER","BASEOBJECT","DEFINITION","WHENCLAUSE","ACTION","ENABLED","TPROPERTY","NAME","BASENAME","BASETYPE","PROPERTY","BTOWNER","BTOWNERID","ACTIONSIZE"
        FROM    sys.exu81tgr
        WHERE   (ownerid, basename) IN (
                    SELECT  ownerid, name
                    FROM    sys.exu9tabc)
      UNION ALL
        SELECT  "OWNERID","OWNER","BASEOBJECT","DEFINITION","WHENCLAUSE","ACTION","ENABLED","TPROPERTY","NAME","BASENAME","BASETYPE","PROPERTY","BTOWNER","BTOWNERID","ACTIONSIZE"
        FROM    sys.exu81tgr
        WHERE   (ownerid, basename) IN (
                    SELECT  ownerid, name
                    FROM    sys.exu8vinfc)
/

