create view ALL_APPLY_TABLE_COLUMNS
            (OBJECT_OWNER, OBJECT_NAME, COLUMN_NAME, COMPARE_OLD_ON_DELETE, COMPARE_OLD_ON_UPDATE,
             APPLY_DATABASE_LINK) as
select do."OBJECT_OWNER",do."OBJECT_NAME",do."COLUMN_NAME",do."COMPARE_OLD_ON_DELETE",do."COMPARE_OLD_ON_UPDATE",do."APPLY_DATABASE_LINK"
  from all_tab_columns a, dba_apply_table_columns do
 where do.object_owner = a.owner
   and do.object_name = a.table_name
   and do.column_name = a.column_name
/

comment on table ALL_APPLY_TABLE_COLUMNS is 'Details about the columns of destination table object visible to the user'
/

comment on column ALL_APPLY_TABLE_COLUMNS.OBJECT_OWNER is 'Owner of the table'
/

comment on column ALL_APPLY_TABLE_COLUMNS.OBJECT_NAME is 'Name of the table'
/

comment on column ALL_APPLY_TABLE_COLUMNS.COLUMN_NAME is 'Name of column'
/

comment on column ALL_APPLY_TABLE_COLUMNS.COMPARE_OLD_ON_DELETE is 'Compare old value of column on deletes'
/

comment on column ALL_APPLY_TABLE_COLUMNS.COMPARE_OLD_ON_UPDATE is 'Compare old value of column on updates'
/

comment on column ALL_APPLY_TABLE_COLUMNS.APPLY_DATABASE_LINK is 'For remote tables, name of database link pointing to remote database'
/

