create view ALL_SCHEDULER_DESTS (OWNER, DESTINATION_NAME, DESTINATION_TYPE, ENABLED, COMMENTS) as
SELECT "OWNER","DESTINATION_NAME","DESTINATION_TYPE","ENABLED","COMMENTS" from dba_scheduler_dests
/

comment on table ALL_SCHEDULER_DESTS is 'All destination objects for jobs in the database visible to current user'
/

comment on column ALL_SCHEDULER_DESTS.OWNER is 'Owner of this destination object'
/

comment on column ALL_SCHEDULER_DESTS.DESTINATION_NAME is 'Name of this destination object'
/

comment on column ALL_SCHEDULER_DESTS.DESTINATION_TYPE is 'Type of this destination object'
/

comment on column ALL_SCHEDULER_DESTS.ENABLED is 'Whether this destination object is enabled'
/

comment on column ALL_SCHEDULER_DESTS.COMMENTS is 'Optional comment'
/

