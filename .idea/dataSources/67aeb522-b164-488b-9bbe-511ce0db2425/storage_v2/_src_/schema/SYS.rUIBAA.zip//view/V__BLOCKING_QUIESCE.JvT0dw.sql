create view V_$BLOCKING_QUIESCE (SID) as
select "SID" from v$blocking_quiesce
/

