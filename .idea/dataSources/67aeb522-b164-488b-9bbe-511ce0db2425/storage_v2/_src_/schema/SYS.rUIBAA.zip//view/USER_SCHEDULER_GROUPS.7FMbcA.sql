create view USER_SCHEDULER_GROUPS (GROUP_NAME, GROUP_TYPE, ENABLED, NUMBER_OF_MEMBERS, COMMENTS) as
SELECT o.name,
  decode(bitand(w.flags, 8+16), 0, 'WINDOW', 8, 'JOB', 16,
decode(bitand(w.flags, 4096+8192), 4096,'DB_DEST', 8192, 'EXTERNAL_DEST', 'UNKOWN_DEST')),
  DECODE(BITAND(w.flags,1),0,'FALSE',1,'TRUE'),
  (SELECT COUNT(*) FROM user_scheduler_group_members ugm WHERE
   ugm.group_name=o.name),
  w.comments
FROM obj$ o, scheduler$_window_group w
WHERE o.obj# = w.obj# AND o.owner# = USERENV('SCHEMAID')
/

comment on table USER_SCHEDULER_GROUPS is 'All scheduler object groups owned by current user'
/

comment on column USER_SCHEDULER_GROUPS.GROUP_NAME is 'Name of the group'
/

comment on column USER_SCHEDULER_GROUPS.GROUP_TYPE is 'Type of object contained in the group'
/

comment on column USER_SCHEDULER_GROUPS.ENABLED is 'Whether the group is enabled'
/

comment on column USER_SCHEDULER_GROUPS.NUMBER_OF_MEMBERS is 'Number of members in this group'
/

comment on column USER_SCHEDULER_GROUPS.COMMENTS is 'An optional comment about this group'
/

