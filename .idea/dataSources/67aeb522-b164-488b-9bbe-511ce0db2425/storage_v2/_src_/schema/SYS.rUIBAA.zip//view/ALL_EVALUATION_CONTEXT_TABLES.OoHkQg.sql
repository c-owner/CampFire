create view ALL_EVALUATION_CONTEXT_TABLES
            (EVALUATION_CONTEXT_OWNER, EVALUATION_CONTEXT_NAME, TABLE_ALIAS, TABLE_NAME) as
SELECT /*+ all_rows */
       u.name, o.name, ect.tab_alias, ect.tab_name
FROM   rec_tab$ ect, obj$ o, user$ u
WHERE  ect.ec_obj# = o.obj# and
       (o.owner# in (USERENV('SCHEMAID'), 1 /* PUBLIC */) or
        o.obj# in (select oa.obj# from sys.objauth$ oa
                   where grantee# in (select kzsrorol from x$kzsro)) or
        exists (select null from v$enabledprivs where priv_number in (
                 -246, /* create any evaluation context */
                 -247, /* alter any evaluation context */
                 -248, /* drop any evaluation context */
                 -249  /* execute any evaluation context */))) and
       o.owner# = u.user#
/

comment on table ALL_EVALUATION_CONTEXT_TABLES is 'tables in all rule evaluation contexts seen by the user'
/

comment on column ALL_EVALUATION_CONTEXT_TABLES.EVALUATION_CONTEXT_OWNER is 'Owner of the evaluation context'
/

comment on column ALL_EVALUATION_CONTEXT_TABLES.EVALUATION_CONTEXT_NAME is 'Name of the evaluation context'
/

comment on column ALL_EVALUATION_CONTEXT_TABLES.TABLE_ALIAS is 'Alias of the table'
/

comment on column ALL_EVALUATION_CONTEXT_TABLES.TABLE_NAME is 'Name of the table'
/

