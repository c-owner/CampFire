create view "_DBA_APPLY_INST_GLOBAL" (SOURCE_DATABASE, INSTANTIATION_EXTERNAL_POS) as
select source_db_name, inst_external_pos
  from "_DBA_APPLY_SOURCE_SCHEMA"
 where global_flag = 1
/

comment on table "_DBA_APPLY_INST_GLOBAL" is 'Details about database instantiated'
/

comment on column "_DBA_APPLY_INST_GLOBAL".SOURCE_DATABASE is 'Name of the database that was instantiated'
/

comment on column "_DBA_APPLY_INST_GLOBAL".INSTANTIATION_EXTERNAL_POS is 'Point in time when the database was instantiated at source'
/

