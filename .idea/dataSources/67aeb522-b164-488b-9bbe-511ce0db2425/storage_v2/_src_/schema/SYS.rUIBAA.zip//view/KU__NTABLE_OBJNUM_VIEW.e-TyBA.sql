create view KU$_NTABLE_OBJNUM_VIEW (OBJ_NUM, SCHEMA_OBJ, BASE_OBJ) as
select t.obj#, value(o), value(bo)
  from ku$_schemaobj_view o, ku$_schemaobj_view bo, sys.tab$ t
  where o.obj_num=t.obj#
  AND bitand(t.property,8192)!=0      /* is a nested table */
  and bo.obj_num=dbms_metadata_util.get_anc(t.obj#)
  and bo.obj_num!=t.obj#
  and (o.owner_name NOT IN ('ORDSYS', 'MDSYS', 'CTXSYS', 'ORDPLUGINS',
                            'LBACSYS', 'XDB', 'SI_INFORMTN_SCHEMA',
                            'EXFSYS', 'DMSYS', 'DVSYS', 'DVF', 'DIP',
                            'DBSNMP', 'WMSYS', 'ORACLE_OCM', 'ANONYMOUS',
                            'XS$NULL', 'TSMSYS', 'APPQOSSYS','MGDSYS'))
  AND (SYS_CONTEXT('USERENV','CURRENT_USERID') IN (o.owner_num, 0)
        OR EXISTS ( SELECT * FROM sys.session_roles
                       WHERE role='SELECT_CATALOG_ROLE' ))
/

