create view DBA_QUEUES
            (OWNER, NAME, QUEUE_TABLE, QID, QUEUE_TYPE, MAX_RETRIES, RETRY_DELAY, ENQUEUE_ENABLED, DEQUEUE_ENABLED,
             RETENTION, USER_COMMENT, NETWORK_NAME)
as
select u.name OWNER, q.name NAME, t.name QUEUE_TABLE, q.eventid QID,
       decode(q.usage, 1, 'EXCEPTION_QUEUE', 2, 'NON_PERSISTENT_QUEUE',
              'NORMAL_QUEUE') QUEUE_TYPE,
       q.max_retries MAX_RETRIES, q.retry_delay RETRY_DELAY,
       decode(bitand(q.enable_flag, 1), 1 , '  YES  ', '  NO  ')ENQUEUE_ENABLED,
       decode(bitand(q.enable_flag, 2), 2 , '  YES  ', '  NO  ')DEQUEUE_ENABLED,
       decode(q.ret_time, -1, ' FOREVER', q.ret_time) RETENTION,
       substr(q.queue_comment, 1, 50) USER_COMMENT,
       s.network_name NETWORK_NAME
from system.aq$_queues q, system.aq$_queue_tables t, sys.user$ u,
dba_services s
where u.name  = t.schema
and   q.table_objno = t.objno
and   q.service_name = s.name (+)
/

comment on table DBA_QUEUES is 'All database queues'
/

comment on column DBA_QUEUES.OWNER is 'Owner of the queue'
/

comment on column DBA_QUEUES.NAME is 'Name of the queue'
/

comment on column DBA_QUEUES.QUEUE_TABLE is 'Name of the table the queue data resides in'
/

comment on column DBA_QUEUES.QID is 'Object number of the queue'
/

comment on column DBA_QUEUES.QUEUE_TYPE is 'Type of the queue'
/

comment on column DBA_QUEUES.MAX_RETRIES is 'Maximum number of retries allowed when dequeuing from the queue'
/

comment on column DBA_QUEUES.RETRY_DELAY is 'Time interval between retries'
/

comment on column DBA_QUEUES.ENQUEUE_ENABLED is 'Queue is enabled for enqueue'
/

comment on column DBA_QUEUES.DEQUEUE_ENABLED is 'Queue is enabled for dequeue'
/

comment on column DBA_QUEUES.RETENTION is 'Time interval processed messages retained in the queue'
/

comment on column DBA_QUEUES.USER_COMMENT is 'User specified comment'
/

comment on column DBA_QUEUES.NETWORK_NAME is 'Network name of queue service'
/

