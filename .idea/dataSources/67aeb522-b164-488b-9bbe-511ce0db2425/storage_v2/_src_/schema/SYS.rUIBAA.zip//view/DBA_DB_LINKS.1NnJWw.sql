create view DBA_DB_LINKS (OWNER, DB_LINK, USERNAME, HOST, CREATED) as
select u.name, l.name, l.userid, l.host, l.ctime
from sys.link$ l, sys.user$ u
where l.owner# = u.user#
/

comment on table DBA_DB_LINKS is 'All database links in the database'
/

comment on column DBA_DB_LINKS.DB_LINK is 'Name of the database link'
/

comment on column DBA_DB_LINKS.USERNAME is 'Name of user to log on as'
/

comment on column DBA_DB_LINKS.HOST is 'SQL*Net string for connect'
/

comment on column DBA_DB_LINKS.CREATED is 'Creation time of the database link'
/

