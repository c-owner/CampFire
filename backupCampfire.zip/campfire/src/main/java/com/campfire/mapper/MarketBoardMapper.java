package com.campfire.mapper;

public interface MarketBoardMapper {

	
}
